﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlaceHolder : MonoBehaviour
{
    [SerializeField]
    private int row = 0, col = 0;

    public SaveElement saveElement { get; private set; } = null;

    void OnMouseDown()
    {
        if (MapGenerator.main.isTrashCan)
        {
            DeleteBlockAndLook();
        }
        else
        {
            SetBlockAndLook();
        }
    }

    public void DeleteBlockAndLook()
    {
        saveElement = null;
        DeleteLook();
    }

    public void SetBlockAndLook()
    {
        SetElement();
        CreateLook();
    }

    private void SetElement()
    {
        saveElement = new SaveElement(MapGenerator.main.currentTool);
        saveElement.row = row;
        saveElement.col = col;
    }

    private void CreateLook()
    {
        DeleteLook();

        GameObject g = ElementHandler.main.DeserializeAt(saveElement, transform.position).gameObject;
        g.transform.SetParent(transform);
    }

    private void DeleteLook()
    {
        if (transform.childCount > 0)
        {
            foreach (Transform child in transform)
            {
                Destroy(child.gameObject);
            }
        }
    }

    public void SetRowAndCol(int row, int col)
    {
        this.row = row;
        this.col = col;
    }
}
