﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MapGenerator : MonoBehaviour
{
    public static MapGenerator main { get; private set; } = null;

    public GameObject placeHolderPrefab;

    private Map map = new Map();
    private string fileName = "default.json";

    private List<PlaceHolder[]> placeHolders = new List<PlaceHolder[]>();

    public int mapLength { get; private set; } = 10;
    private int maxCols = 10;


    private int topRowIndex = 0;
    private int bottomRowIndex = 0;
    private Vector3 startPosition;
    private float squareSize;

    // Handling interactions.
    public SaveElement currentTool { get; private set; }
    public bool isTrashCan { get; private set; }

    public int currentMaxHp { get; private set; } = 10;
    public Color currentColor { get; private set; } = Color.white;

    void Awake()
    {
        if(main == null)
        {
            main = this;
        }
    }

    void Start()
    {
        squareSize = ElementHandler.main.squareSize;
        float sideSize = ElementHandler.main.sideSize;

        startPosition = new Vector3(-Camera.main.orthographicSize * Camera.main.aspect + squareSize / 2 + sideSize, -Camera.main.orthographicSize + (squareSize / 2 + sideSize), 0);
        isTrashCan = false;

        AddPlaceHolders();
        SetDefaultTool();
        // Debug.
        //DebugFunction();
    }

    // HACK debug.
    private void DebugFunction()
    {
        SetToolType(PowerUp.Type.POWERUP_DINO);
        placeHolders[2][5].SetBlockAndLook();
        placeHolders[2][5].SetBlockAndLook();
        SetToolType(Square.Type.SQUARE);
        placeHolders[3][7].SetBlockAndLook();
        placeHolders[8][2].SetBlockAndLook();
    }
    

    #region PlaceHolders
    public void AddPlaceHolders()
    {
        for (int i = placeHolders.Count; i < mapLength; i++)
        {
            AddPlaceHolderRow(MapPosition.TOP);
        }
    }

    private void AddPlaceHolderRow(MapPosition position)
    {
        int listIndex = 0;
        int positionIndex = (position == MapPosition.TOP) ? topRowIndex : bottomRowIndex;
        if(position == MapPosition.TOP)
        {
            if(placeHolders.Count != 0)
            {
                positionIndex = ++topRowIndex;
            }
            listIndex = placeHolders.Count;
            placeHolders.Add(new PlaceHolder[maxCols]);
        }
        else
        {
            if (placeHolders.Count != 0)
            {
                positionIndex = --bottomRowIndex;
            }
            listIndex = 0;
            placeHolders.Insert(listIndex, new PlaceHolder[maxCols]);
        }
        for (int j = 0; j < maxCols; j++)
        {
            Vector3 pos = startPosition + new Vector3(j, positionIndex) * squareSize;
            
            placeHolders[listIndex][j] = GeneratePlaceHolder(pos, listIndex, j);
        }
    }

    private void RemovePlaceHolderRow(MapPosition position)
    {
        int listIndex;
        Debug.Log("Top: " + topRowIndex + " Bottom: " + bottomRowIndex);
        if(placeHolders.Count < 1)
        {
            return;
        } 
        else if(placeHolders.Count == 1)
        {
            listIndex = 0;
        }
        else if (position == MapPosition.TOP)
        {
            listIndex = placeHolders.Count - 1;
            topRowIndex--;
        }
        else
        {
            listIndex = 0;
            bottomRowIndex++;
        }

        Debug.Log("After\nTop: " + topRowIndex + " Bottom: " + bottomRowIndex);

        foreach (PlaceHolder p in placeHolders[listIndex])
        {
            Destroy(p.gameObject);
        }
        placeHolders.RemoveAt(listIndex);
    }

    private PlaceHolder GeneratePlaceHolder(Vector3 position, int row, int col)
    {
        GameObject g = Instantiate(placeHolderPrefab, position, Quaternion.identity);

        PlaceHolder p = g.GetComponent<PlaceHolder>();
        p.SetRowAndCol(row, col);

        return p;
    }

    #endregion

    #region UIfunctions
    /*
        Functions for the UI elements.
    */
    // TODO: Removing- and adding lines implementation.
    public void AddRowTo(MapPosition mapPos)
    {
        AddPlaceHolderRow(mapPos);
    }

    public void RemoveRowFrom(MapPosition pos)
    {
        RemovePlaceHolderRow(pos);
    }

    public void ReceiveMaxHp(int maxHp)
    {
        this.currentMaxHp = maxHp;
        RefreshCurrentTool();
    }

    public void RecieveColor(Color color)
    {
        currentColor = color;
    }

    public void SetToolType(Element.Type type)
    {
        if (Element.IsDestroyable(type))
        {
            currentTool.destroyable.maxHp = currentMaxHp;
            currentTool.destroyable.color = currentColor;
        }

        currentTool.type = type;
    }

    public void SetTrashCan()
    {
        isTrashCan = !isTrashCan;
    }

    public void SaveMap()
    {
        BuildMapToSave();
        SaveLoadHandlerJSON<Map>.Save(map, fileName);
    }

    public void LoadMap(string fileName)
    {
        map = SaveLoadHandlerJSON<Map>.Load(fileName);
        BuildMapFromLoad();
    }
    /*
        Functions for the UI elements.
    */
    #endregion


    #region BackEndToUI
    private void SetDefaultTool()
    {
        currentTool = new SaveElement(Element.Type.SQUARE, 0, 0, new SaveDestroyable(currentMaxHp, Color.white));
    }

    private void RefreshCurrentTool()
    {
        if (Element.IsDestroyable(currentTool.type))
        {
            SetToolType(currentTool.type);
        }
    }

    private void BuildMapToSave()
    {
        map = new Map();
        Vector2Int usefulLines = UsefulLinesFromX2Y();
        int start = usefulLines.x;
        int end = usefulLines.y;

        for (int i = start; i < end; i++)
        {
            map.lines.Add(new SaveElementLine());
            for (int j = 0; j < placeHolders[i].Length; j++)
            {
                if (placeHolders[i][j].saveElement != null)
                {
                    map.lines[i].list.Add(new SaveElement(placeHolders[i][j].saveElement));
                }
            }
        }
    }

    // TODO: Implement the loading mechanism.
    private void BuildMapFromLoad()
    {

    }

    // HACK: In theory this part is fine, but needs further testing on edge cases.
    private Vector2Int UsefulLinesFromX2Y()
    {
        Vector2Int useful = new Vector2Int(placeHolders.Count, 0);

        for (int i = 0; i < placeHolders.Count; i++)
        {
            if (!isRowEmpty(placeHolders[i]))
            {
                useful.x = i;
                break;
            }
        }
        for (int j = placeHolders.Count - 1; j >= useful.x; j--)
        {
            if (!isRowEmpty(placeHolders[j]))
            {
                useful.y = j + 1;
                break;
            }
        }

        return useful;
    }

    private bool isRowEmpty(PlaceHolder[] pHolders)
    {
        for (int i = 0; i < pHolders.Length; i++)
        {
            if(pHolders[i] != null)
            {
                return false;
            }
        }
        return true;
    }
    #endregion


    public enum MapPosition
    {
        TOP,
        BOTTOM
    }
}
