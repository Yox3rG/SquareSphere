﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIHandlerMapGen : MonoBehaviour
{
    // New panels should be added into the fill method.
    public Button propertiesTabButton;
    public Button buildTabButton;
    public Button paletteTabButton;

    public GameObject propertiesPanel;
    public GameObject buildPanel;
    public GameObject palettePanel;

    public InputField hpInputField;


    private List<Button> tabs = new List<Button>();
    private List<GameObject> panels = new List<GameObject>();

    private int currentTab = 0;
    private Color32 activeColor;
    private Color32 passiveColor;


    void Start()
    {
        passiveColor = new Color32(105, 112, 130, 255);
        activeColor = new Color32(70, 82, 116, 255);
        FillTabsAndPanels();

        SetDefaultTabAndPanelState();
    }


    public void Save()
    {
        MapGenerator.main.SaveMap();
    }

    public void Load()
    {
        string fileName = LoadGamePopUpWindow();
        MapGenerator.main.LoadMap(fileName);
    }

    public void TrashCan()
    {
        MapGenerator.main.SetTrashCan();
    }

    public void ChangeTabTo(int newTab)
    {
        if(newTab != currentTab && newTab >= 0 && newTab < tabs.Count)
        {
            SetTabAndPanelActive(currentTab, false);

            SetTabAndPanelActive(newTab, true);

            currentTab = newTab;
        }
    }

    public void AddRowToTop()
    {
        MapGenerator.main.AddRowTo(MapGenerator.MapPosition.TOP);
    }

    public void AddRowToBottom()
    {
        MapGenerator.main.AddRowTo(MapGenerator.MapPosition.BOTTOM);
    }

    public void RemoveRowFromTop()
    {
        MapGenerator.main.RemoveRowFrom(MapGenerator.MapPosition.TOP);
    }

    public void RemoveRowFromBottom()
    {
        MapGenerator.main.RemoveRowFrom(MapGenerator.MapPosition.BOTTOM);
    }

    public void OnMaxHpChanged()
    {
        int maxHp = MapGenerator.main.currentMaxHp;
        if(int.TryParse(hpInputField.text, out maxHp))
        {

        }
        if(maxHp <= 0)
        {
            maxHp = 1;
        }

        Debug.Log(maxHp);

        MapGenerator.main.ReceiveMaxHp(maxHp);
    }

    public void OnMaxHpEditEnd()
    {
        hpInputField.text = MapGenerator.main.currentMaxHp.ToString();
    }






    private void SetDefaultTabAndPanelState()
    {
        currentTab = 0;
        SetTabAndPanelActive(currentTab, true);

        for (int i = 1; i < tabs.Count; i++)
        {
            SetTabAndPanelActive(i, false);
        }
    }

    private void SetTabAndPanelActive(int index, bool value)
    {
        tabs[index].GetComponent<Image>().color = GetActiveColor(value);
        panels[index].SetActive(value);
    }

    private Color32 GetActiveColor(bool value)
    {
        if (value)
        {
            return activeColor;
        }
        else
        {
            return passiveColor;
        }
    }

    private void FillTabsAndPanels()
    {
        tabs.Add(propertiesTabButton);
        panels.Add(propertiesPanel);

        tabs.Add(buildTabButton);
        panels.Add(buildPanel);

        tabs.Add(paletteTabButton);
        panels.Add(palettePanel);
    }

    // TODO PopupWindow Scripts.
    private string LoadGamePopUpWindow()
    {
        return "default.json";
    }
}
