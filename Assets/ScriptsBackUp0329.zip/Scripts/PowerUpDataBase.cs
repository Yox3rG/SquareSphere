﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PowerUpDataBase : MonoBehaviour
{
    public static PowerUpDataBase main = null;


    private List<PowerUp> powerUps = new List<PowerUp>();

    void Awake()
    {
        if(main == null)
        {
            main = this;
        }
    }

    /*
    public void NextRound()
    {
        foreach(PowerUp p in powerUps)
        {
            if(p != null)
            {
                if (p.isDestroyedNextTurn)
                {
                    Destroy(p.gameObject);
                }
                else
                {
                    p.LiftDown(true);
                }
            }
        }
    }
     */
}
