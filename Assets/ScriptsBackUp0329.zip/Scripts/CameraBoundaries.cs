﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CameraBoundaries : MonoBehaviour
{
    public GameObject topPanel;

    private GameObject[] bounds;

    private enum Side : int { LEFT = 0, TOP, RIGHT, BOTTOM };

    void Start()
    {
        bounds = new GameObject[4];

        Camera cam = GetComponent<Camera>();
        float top = cam.orthographicSize;
        float right = cam.orthographicSize * cam.aspect;

        int negativeSide = -1;

        for (int i = 0; i < 4; i++)
        {
            bounds[i] = new GameObject("Boundary " + i);
            bounds[i].layer = 12;
            BoxCollider2D boxCol = bounds[i].AddComponent<BoxCollider2D>();

            if(i % 2 == 0)
            {
                boxCol.size = new Vector2(1, top * 2);
                boxCol.transform.position = new Vector3(right + .5f, 0) * negativeSide;

                negativeSide *= -1;
            }
            else
            {
                boxCol.size = new Vector2(right * 2, 1);
                boxCol.transform.position = new Vector3(0, top + .5f) * negativeSide;
            }
        }

        AlignTopToUI();
    }
    
    private void AlignTopToUI()
    {
        Camera cam = GetComponent<Camera>();
        float sizeOfPanel = cam.orthographicSize;
        sizeOfPanel -= topPanel.GetComponent<RectTransform>().position.y;
        sizeOfPanel *= 2;

        BoxCollider2D bc = bounds[(int)Side.TOP].GetComponent<BoxCollider2D>();
        bc.size = new Vector2(bc.size.x, sizeOfPanel);

        Transform t = bounds[(int)Side.TOP].transform;
        t.position = topPanel.GetComponent<RectTransform>().position;
    }
}
