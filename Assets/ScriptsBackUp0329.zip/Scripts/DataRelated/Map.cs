﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Map
{
    public List<SaveElementLine> lines = new List<SaveElementLine>();
}
