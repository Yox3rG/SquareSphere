﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MapDataBase : MonoBehaviour
{
    public static MapDataBase main = null;

    private Map map = new Map();

    private string fileName = "test.json";

    private int currentIndex = 0;

    void Awake()
    {
        if(main == null)
        {
            main = this;
        }
    }

    void Start()
    {

        map = SaveLoadHandlerJSON<Map>.Load("default.json");
        Test();
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.S))
        {
            SaveLoadHandlerJSON<Map>.Save(map, fileName);
        }
        if (Input.GetKeyDown(KeyCode.L))
        {
            map = SaveLoadHandlerJSON<Map>.Load(fileName);
        }
    }

    public List<SaveElement> GetNextLine()
    {
        if(currentIndex < map.lines.Count)
        {
            return map.lines[currentIndex++].list;
        }
        else
        {
            return new List<SaveElement>();
        }
    }

    public int GetMapLength()
    {
        return map.lines.Count;
    }

    private void Test()
    {
        map = new Map();
        for (int i = 0; i < 10; i++)
        {
            map.lines.Add(new SaveElementLine());
            map.lines[i].list.Add(new SaveElement(Element.Type.SQUARE, 1, 1));
            map.lines[i].list.Add(new SaveElement(Element.Type.TRIANGLE_180, 3, 1));
            map.lines[i].list.Add(new SaveElement(Element.Type.TRIANGLE_90, 4, 1));
                        
            map.lines[i].list.Add(new SaveElement(Element.Type.POWERUP_BOTH_LINE, 1, 2));
        }
        currentIndex = 0;
    }
}
