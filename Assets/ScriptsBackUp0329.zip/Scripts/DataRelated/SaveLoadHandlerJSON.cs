﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

public class SaveLoadHandlerJSON<T>
{
    private static string path = Application.persistentDataPath;



    public static void Save(T data, string fileName)
    {
        string tempPath = Path.Combine(path, fileName);


        using (StreamWriter streamWriter = File.CreateText(tempPath))
        {
            string jsonString = JsonUtility.ToJson(data);
            streamWriter.Write(jsonString);
        }
        Debug.Log("Saved succesfully");
    }
    
    public static T Load(string fileName)
    {
        string tempPath = Path.Combine(path, fileName);

        //BinaryFormatter binaryFormatter = new BinaryFormatter();
        //FileStream fileStream = File.Open(fileName, FileMode.Open);

        using (StreamReader streamReader = File.OpenText(tempPath))
        {
            string jsonString = streamReader.ReadToEnd();
            Debug.Log("Loaded succesfully");
            return JsonUtility.FromJson<T>(jsonString);
        }
    }
}
