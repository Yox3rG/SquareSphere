﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class Menu : MonoBehaviour
{
    public static Menu main { get; private set; }


    public GameObject canvas;
    public GameObject gameCanvas;

    // Panels.
    public GameObject menuPanel;
    public GameObject shopPanel;

    // ScrollViews.
    public GameObject lvlScrollContent;
    public GameObject shopScrollContent;

    // Prefabs.
    public GameObject lvlPrefab;
    public GameObject shopPrefab;

    
    private int currentLvl = 0;

    void Awake()
    {
        if(main == null)
        {
            main = this;
            DontDestroyOnLoad(this);
            DontDestroyOnLoad(canvas);

            currentLvl = 0;
        }
        else
        {
            Destroy(canvas);
            Destroy(gameObject);
        }
    }

    void Start()
    {
        SetDefaultState();
    }

    private void GenerateLvlPrefabs(int lvlCount)
    {
        GeneratePrefabs(lvlCount, lvlPrefab, lvlScrollContent.transform);
    }

    private void GenerateShopPrefabs(int itemCount)
    {
        GeneratePrefabs(itemCount, shopPrefab, shopScrollContent.transform);
    }

    private void GeneratePrefabs(int count, GameObject prefab, Transform parent)
    {
        for (int i = 0; i < count; i++)
        {
            GameObject g = Instantiate(prefab, parent);
            g.GetComponentInChildren<Text>().text = i.ToString();
            g.name = "lvl-" + i;
            int iValue = i;
            g.GetComponent<Button>().onClick.AddListener(delegate { SetLvl(iValue); });
        }
    }

    public int GetCurrentLvl()
    {
        return currentLvl;
    }

    public void SetLvl(int lvl)
    {
        currentLvl = lvl;
        SetGameScreen();
    }

    public void SetShopActive(bool value)
    {
        shopPanel.SetActive(value);
        menuPanel.SetActive(!value);
    }

    public void SetHomeScreen()
    {
        SceneManager.LoadScene(0);
        canvas.SetActive(true);
        //SetDefaultState();
    }

    public void SetGameScreen()
    {
        SceneManager.LoadScene(1);
        canvas.SetActive(false);
        Time.timeScale = 1;
    }

    public void SetDefaultState()
    {
        canvas.SetActive(true);

        SetShopActive(false);

        GenerateLvlPrefabs(100);
        GenerateShopPrefabs(10);
    }
}
