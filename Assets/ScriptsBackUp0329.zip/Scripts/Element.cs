﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Element : MonoBehaviour
{
    public int row { get; protected set; }
    public int col { get; protected set; }

    public Type type { get; protected set; }

    // Used mostly for random generating types.
    public const int destroyableStart = 0;
    public const int destroyableEnd = 4;
    public const int powerupStart = 100;
    public const int powerupEnd = 106;

    public enum Type
    {
        // DESTROYABLES
        SQUARE = destroyableStart,

        TRIANGLE_0,
        TRIANGLE_90,
        TRIANGLE_180,
        TRIANGLE_270,


        // POWERUPS
        POWERUP_BONUSBALL = powerupStart,
        POWERUP_HORIZONTAL_LINE,
        POWERUP_VERTICAL_LINE,
        POWERUP_BOTH_LINE,
        POWERUP_DINO,
        POWERUP_GOLD,
        POWERUP_STAR
    }

    public static bool IsDestroyable(Type type)
    {
        int typeNumber = (int)type;
        if(typeNumber >= destroyableStart && typeNumber <= destroyableEnd)
        {
            return true;
        }
        return false;
    }

    public static bool IsPowerUp(Type type)
    {
        int typeNumber = (int)type;
        if (typeNumber >= powerupStart && typeNumber <= powerupEnd)
        {
            return true;
        }
        return false;
    }

    // TODO: Check if these can simplify things...
    public bool IsDestroyable()
    {
        return IsDestroyable(type);
    }

    public bool IsPowerUp()
    {
        return IsPowerUp(type);
    }

    public void SetRowAndCol(int row, int col)
    {
        this.row = row;
        this.col = col;
    }

    public virtual void SetType(Type type)
    {
        this.type = type;
    }
}
