﻿using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class Square : Element
{
    protected Text text;

    public int hp { get; protected set; } = 100;
    
    public byte colorIndex { get; protected set; }

    void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.layer == 10)
        {
            TakeDmg(collision.transform.GetComponent<Ball>().dmg);
        }
    }

    void OnDestroy()
    {
        if(text != null)
        {
            Destroy(text.gameObject);
        }
    }

    public void TakeDmg(int dmg)
    {
        hp -= dmg;
        ProfileDataBase.main?.StatIncreaseDamageDealt(dmg);
        if(hp <= 0)
        {
            Break();
        }
        text.text = hp.ToString();
    }

    public void SetColor(byte colorIndex)
    {
        this.colorIndex = colorIndex;
        GetComponent<SpriteRenderer>().color = Palette.GetColor(colorIndex);
    }

    public virtual void SetMaxHp(int hp)
    {
        this.hp = hp;
        text.text = hp.ToString();
    }

    public virtual void ResetTextPosition()
    {
        TextGenerator.main.Move(text.gameObject, transform.position);
    }

    public void SetTextObject(Text t)
    {
        text = t;
    }


    public void Break()
    {
        ProfileDataBase.main?.StatIncreaseBlocksBroken();
        SquareDataBase.main.AddScore();

        GetComponent<SubjectSquare>().OnDeathFunction();
        Destroy(gameObject);
    }
}
