﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BallBasket : MonoBehaviour
{
    public static BallBasket main { get; private set; } = null;

    private Vector3 startPosition;
    private float colliderHeight = 1;

    private bool first = false;

    void Start()
    {
        if(main == null)
        {
            main = this;
        }

        GetComponent<BoxCollider2D>().size = new Vector2(Camera.main.orthographicSize * Camera.main.aspect * 2, colliderHeight);
        startPosition = new Vector3(0, -Camera.main.orthographicSize + colliderHeight / 2, 0);
    }


    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.layer == 10)
        {
            Ball ball = collision.transform.GetComponent<Ball>();

            if (first)
            {
                BallController.main.FirstBallFell(ball.transform.position);
                first = false;
            }

            ball.Return();
            BallController.main.BallFellDown();

        }
    }

    public void GameIsRolling()
    {
        first = true;
    }

    public void GameStoppedRolling()
    {
        first = false;
    }
}
