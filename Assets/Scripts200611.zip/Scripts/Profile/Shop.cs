﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Shop
{
    public List<bool> ballsUnlocked = new List<bool>();
    private List<int> ballCostList = new List<int>() { 0,       100,        100,        100,        100,        100,
                                                       100,     100,        100,        100,        100,        100,
                                                       1000,     1000,        1000,        1000,        1000,        1000,
                                                       1000,     1000,        1000,        1000,        1000,        1000,
                                                       1000,     1000,        1000,        1000,        1000,        1000,
                                                       2000,     2000};

    public int selectedBall = 0;

    public int BallCostListCount()
    {
        return ballCostList.Count;
    }

    public int GetBallCost(int index)
    {
        return ballCostList[index];
    }

    public int UnlockedBallCount()
    {
        int count = 0;
        foreach(bool b in ballsUnlocked)
        {
            if (b)
            {
                count++;
            }
        }

        return count;
    }
}
