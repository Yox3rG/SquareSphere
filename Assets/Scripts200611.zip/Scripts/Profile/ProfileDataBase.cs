﻿using System.Collections.Generic;
using System.IO;
using System.Text;
using UnityEngine;

public class ProfileDataBase : MonoBehaviour
{
    public static ProfileDataBase main = null;

    private DataCollection data = new DataCollection();

    private const bool isAnalysing = true;
    public const string chainAnalysisFileName = "chainAnalysis";

    // HACK This file layout is different in the way it declares variables.
    // More specific variables are defined right before the section that uses them.
    // Enums are exceptions.
    public enum PaymentResult
    {
        SUCCESS,
        NOT_ENOUGH_CURRENCY,
        NO_SUCH_ITEM,
        ALREADY_PURCHASED,
        UNSPECIFIED_ERROR
    }


    void Awake()
    {
        if (main == null)
        {
            main = this;
            DontDestroyOnLoad(this);
        }
        else
        {
            Destroy(gameObject);
        }

        LoadShopResources();

        string dataFolder = Path.Combine(Application.persistentDataPath, data.GetFileLocation());
        if (!Directory.Exists(dataFolder))
        {
            Directory.CreateDirectory(dataFolder);
        }

        if (!data.LoadData())
        {
            SetDefaultData();
        }
    }

    void Start()
    {
        

        //DebugFunction();
    }

    private void Update()
    {
        LvlDebug(300);
    }

    // HACK debug.
    #region DEBUG
    private void LvlDebug(int xpGained)
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            GainXp(xpGained);

            Debug.Log("You're lvl " + data.profile.level + ", and have " + data.profile.experienceOnCurrentLevel + " xp on this level.");
            Debug.Log("You need " + NextLvlRequirement(data.profile.level) + " xp for next level, and gained " + data.stats.experienceGained + " xp overall.");

            Debug.Log(ValidLvlCheck() ? "You have a valid lvl." : "Your lvl is invalid.");
        }
    }

    private void DebugFunction()
    {
        /*
        for (int i = 0; i < 20; i++)
        {
            Debug.Log("NextLvlReq " + i + " : " + NextLvlRequirement(i));
        }
        */
        for (int i = 0; i < 1000; i++)
        {
        }
    }

    private float TestTimeNormal(int i)
    {
        float start = Time.realtimeSinceStartup;

        XpNeededForLvl(i);

        float end = Time.realtimeSinceStartup;

        return end - start;
    }
    #endregion


    #region GoldSection
    public void GainGold(int amount)
    {
        data.profile.gold += amount;
    }
    
    private bool SpendGold(int amount)
    {
        int tempGold = data.profile.gold - amount;
        if(tempGold >= 0)
        {
            data.profile.gold = tempGold;
            return true;
        }
        else
        {
            return false;
        }
    }

    public int GetCurrentGold()
    {
        return data.profile.gold;
    }

    public PaymentResult BuyBall(int index)
    {
        if(index >= data.shop.BallCostListCount() || index < 0)
        {
            return PaymentResult.NO_SUCH_ITEM;
        }
        else if (IsBallUnLocked(index))
        {
            return PaymentResult.ALREADY_PURCHASED;
        }

        if (!SpendGold(data.shop.GetBallCost(index)))
        {
            return PaymentResult.NOT_ENOUGH_CURRENCY;
        }
        else
        {
            data.shop.ballsUnlocked[index] = true;
            data.shop.selectedBall = index;
            return PaymentResult.SUCCESS;
        }

        //return PaymentResult.UNSPECIFIED_ERROR;
    }
    #endregion

    private readonly int[] xpGainedPerStar = { 2, 3, 4 };

    #region LevelCompletition
    public void CompleteLevel(int level, byte starScore)
    {
        if(starScore > 0 && starScore < 4)
        {
            // Count here represents the next index in the list.
            int nextIncompleteLevel = data.profile.starsOnMaps.Count;

            if (nextIncompleteLevel == level)
            {
                GainXp(StarsToXp(0, starScore));
                Debug.Log(StarsToXp(0, starScore));

                data.profile.starsOnMaps.Add(starScore);
                data.profile.stars += starScore;
            }
            else if(nextIncompleteLevel > level)
            {
                int differenceInStars = starScore - data.profile.starsOnMaps[level];
                if (0 < differenceInStars)
                {
                    GainXp(StarsToXp(data.profile.starsOnMaps[level], starScore));
                    Debug.Log(StarsToXp(data.profile.starsOnMaps[level], starScore));

                    data.profile.starsOnMaps[level] = starScore;
                    data.profile.stars += differenceInStars;
                }
            }
            else
            {
                Debug.Log("Invalid level completed. (level number too high)");
            }
        }
    }

    private int StarsToXp(int oldStarCount, int newStarCount)
    {
        int amount = 0;
        for(int i = oldStarCount; i < newStarCount; i++)
        {
            amount += xpGainedPerStar[i];
        }
        return amount;
    }

    public bool IsLevelPlayable(int level)
    {
        if(level <= data.profile.starsOnMaps.Count)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public int GetLastPlayableMap()
    {
        return data.profile.starsOnMaps.Count;
    }

    public byte GetStarsOnMap(int level)
    {
        return data.profile.starsOnMaps[level];
    }

    public long GetCurrentStars()
    {
        return data.profile.stars;
    }
    #endregion

    private List<Sprite> ballSpriteSheetShop = new List<Sprite>();
    private List<Sprite> ballSpriteSheetGame = new List<Sprite>();

    #region Shop
    private void LoadShopResources()
    {
        ballSpriteSheetShop = new List<Sprite>();
        ballSpriteSheetGame = new List<Sprite>();

        ballSpriteSheetShop.AddRange(Resources.LoadAll<Sprite>("shopBalls"));
        ballSpriteSheetGame.AddRange(Resources.LoadAll<Sprite>("gameBalls"));
    }

    public Sprite GetShopBallResource(int index)
    {
        return ballSpriteSheetShop[index];
    }

    private Sprite GetGameBallSprite(int index)
    {
        return ballSpriteSheetGame[index];
    }

    public int GetBallPrice(int index)
    {
        return data.shop.GetBallCost(index);
    }

    public void SelectBall(int index)
    {
        data.shop.selectedBall = index;
    }

    public int GetSelectedBallIndex()
    {
        return data.shop.selectedBall;
    }

    public Sprite GetSelectedGameBallSprite()
    {
        return GetGameBallSprite(data.shop.selectedBall);
    }

    public bool IsBallUnLocked(int index)
    {
        return data.shop.ballsUnlocked[index];
    }

    public int NumberOfBallResources()
    {
        return ballSpriteSheetShop.Count;
    }
    #endregion

    private readonly int[] lvlRequirements = 
        { 0, 10, 14, 22, 34, 46, 60, 76, 92, 112, 132, 154, 178, 202, 230, 258, 288, 320, 352, 388, 424, 
        462, 502, 542, 586, 630, 676, 724, 772, 828, 888, 952, 1020, 1092, 1168, 1248, 1332, 1420, 1512, 1608, 1708, 696969 }; // The last one would be for lvl 41.
    private readonly int maxLvl = 40;

    #region ExperienceSection
    public void GainXp(int amount)
    {
        data.profile.experienceOnCurrentLevel += amount;
        data.stats.experienceGained += amount;

        while(data.profile.experienceOnCurrentLevel >= NextLvlRequirement(data.profile.level) && data.profile.level < maxLvl)
        {
            LevelUp();
        }
    }

    private void LevelUp()
    {
        data.profile.experienceOnCurrentLevel -= NextLvlRequirement(data.profile.level);
        data.profile.level++;
    }

    private long NextLvlRequirement(int currentLvl)
    {
        return System.Convert.ToInt64(lvlRequirements[currentLvl + 1]);
    }

    private bool ValidLvlCheck()
    {
        return XpNeededForLvl(data.profile.level) + data.profile.experienceOnCurrentLevel == data.stats.experienceGained;
    }

    private long XpNeededForLvl(int lvl)
    {
        long amount = 0;
        for (int i = 0; i <= lvl; i++)
        {
            amount += lvlRequirements[i];
            Debug.Log(amount);
        }

        return amount;
    }

    public long GetExperienceOnCurrentLevel()
    {
        return data.profile.experienceOnCurrentLevel;
    }

    public int GetCurrentLevel()
    {
        return data.profile.level;
    }
    #endregion

    #region StatSection
    public string GetStatisticString()
    {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.AppendLine("Levels failed: " + data.stats.deathCount);
        stringBuilder.AppendLine("Levels completed: " + (GetLastPlayableMap() - 1));
        stringBuilder.AppendLine("Levels started: " + data.stats.levelsStarted);
        stringBuilder.AppendLine("Levels quit: " + data.stats.levelsQuit);
        stringBuilder.AppendLine("Balls fired: " + data.stats.ballsFired);
        stringBuilder.AppendLine("Blocks broken: " + data.stats.blocksBroken);
        stringBuilder.AppendLine("... in one round: " + data.stats.blocksBrokenOneRound);
        stringBuilder.AppendLine("Damage dealt: " + data.stats.damageDealt);
        stringBuilder.AppendLine("Highest score: " + data.stats.highestScore);
        stringBuilder.AppendLine("Balls unlocked: " + data.shop.UnlockedBallCount());
        stringBuilder.AppendLine("Game open for: " + data.stats.timeSpent.ToString("F1") + " seconds");

        return stringBuilder.ToString();
    }

    // SquareDataBase
    public void StatIncreaseDeath()
    {
        data.stats.deathCount++;
    }

    // Menu
    public void StatIncreaseLevelsStarted()
    {
        data.stats.levelsStarted++;
    }

    // GamePlayMenu
    public void StatIncreaseLevelsQuit()
    {
        data.stats.levelsQuit++;
    }

    // BallController
    public void StatIncreaseBallsFired()
    {
        data.stats.ballsFired++;
    }

    // Square
    public void StatIncreaseBlocksBroken()
    {
        data.stats.blocksBroken++;
    }

    // BallController
    public void StatSetBlocksBrokenOneRound(int value)
    {
        data.stats.blocksBrokenOneRound = value;
    }

    // Square
    public void StatIncreaseDamageDealt(int damage)
    {
        data.stats.damageDealt += damage;
    }

    public void StatSetHighestScore(int value)
    {
        data.stats.highestScore = value;
    }

    public void StatIncreaseTimeSpent(float seconds)
    {
        data.stats.timeSpent += seconds;
    }

    // Getters ---------------------
    public long GetBlocksBroken()
    {
        return data.stats.blocksBroken;
    }

    public int GetBlocksBrokenOneRound()
    {
        return data.stats.blocksBrokenOneRound;
    }

    public int GetHighestScore()
    {
        return data.stats.highestScore;
    }
    #endregion

    #region Settings
    public void ChangeDefaultMasterVolume(float value)
    {
        data.settings.masterVolume = value;
    }

    public void ChangeDefaultMusicVolume(float value)
    {
        data.settings.musicVolume = value;
    }

    public void ChangeDefaultSFXVolume(float value)
    {
        data.settings.sfxVolume = value;
    }

    public Dictionary<string, float> GetMusicVolumes()
    {
        Dictionary<string, float> d = new Dictionary<string, float>();
        d.Add("masterVol", data.settings.masterVolume);
        d.Add("musicVol", data.settings.musicVolume);
        d.Add("sfxVol", data.settings.sfxVolume);

        return d;
    }
    #endregion

    public void ChangeName(string name)
    {
        data.profile.name = name;
    }

    public string GetName()
    {
        return data.profile.name;
    }

    private void SetDefaultData()
    {
        data.profile = new Profile();
        data.stats = new Statistics();
        data.shop = new Shop();

        data.shop.ballsUnlocked = new List<bool>();
        data.shop.ballsUnlocked.Add(true);
        for (int i = 1; i < NumberOfBallResources(); i++)
        {
            data.shop.ballsUnlocked.Add(false);
        }

        // HACK Debug.
        /*
        data.shop.ballsUnlocked.Remove(false);
        data.shop.ballsUnlocked.Remove(false);
        data.shop.ballsUnlocked.Remove(false);
        data.shop.ballsUnlocked.Remove(false);
        data.shop.ballsUnlocked.Remove(false);
        data.shop.ballsUnlocked.Remove(false);
        data.shop.ballsUnlocked.Remove(false);
        data.shop.ballsUnlocked.Remove(false);
        data.shop.ballsUnlocked.Remove(false);
        data.shop.ballsUnlocked.Add(true);
        data.shop.ballsUnlocked.Add(true);
        data.shop.ballsUnlocked.Add(true);
        data.shop.ballsUnlocked.Add(true);
        data.shop.ballsUnlocked.Add(true);
        data.shop.ballsUnlocked.Add(true);
        data.shop.ballsUnlocked.Add(true);
        data.shop.ballsUnlocked.Add(true);
        data.shop.ballsUnlocked.Add(true);
        data.profile.gold = 400;
        */
    }

    public bool CreateHeaderToChainAnalysis()
    {
        if (isAnalysing && !SaveLoadHandlerJSON<int>.FileExists(chainAnalysisFileName))
        {
            SaveLoadHandlerJSON<string>.AppendLine(
                "Level #,Round #,count_balls,count_chain,count_visible",
                chainAnalysisFileName);
        }
        return false;
    }

    public bool AppendLineToChainAnalysis(int chainCount)
    {
        if (isAnalysing)
        {
            int level_num, round_num, count_balls, count_chain, count_visible;
            level_num = round_num = count_balls = count_chain = count_visible = 0;

            level_num = Menu.main.GetCurrentLvl();
            round_num = SquareDataBase.main?.GetCurrentRound() ?? 696969;
            count_balls = BallController.main?.GetMaxNumOfBalls() ?? 696969;
            count_chain = chainCount;
            count_visible = SquareDataBase.main?.GetVisibleDestroyableCount() ?? 696969;

            System.Text.StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.Append(level_num + ",");
            stringBuilder.Append(round_num + ",");
            stringBuilder.Append(count_balls + ",");
            stringBuilder.Append(count_chain + ",");
            stringBuilder.Append(count_visible);


            SaveLoadHandlerJSON<string>.AppendLine(
                stringBuilder.ToString(),
                chainAnalysisFileName);
        }
        return false;
    }

    public bool SaveData()
    {
        return data.SaveData();
    }
}
