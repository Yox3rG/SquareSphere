﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PowerUpDataBase : MonoBehaviour
{
    public static PowerUpDataBase main = null;


    public GameObject powerUpPrefab;


    private List<PowerUp> powerUps = new List<PowerUp>();

    void Awake()
    {
        if(main == null)
        {
            main = this;
        }
    }

    public void NextRound()
    {
        foreach(PowerUp p in powerUps)
        {
            if(p != null)
            {
                if (p.isDestroyedNextTurn)
                {
                    Destroy(p.gameObject);
                }
                else
                {
                    p.LiftDown(true);
                }
            }
        }
    }

    public GameObject GeneratePowerUpRandom(Vector3 position, Vector2Int intPosition)
    {
        PowerUp.Type type = (PowerUp.Type)Random.Range(0, (int)PowerUp.Type.COUNT);

        return GeneratePowerUp(position, intPosition, type);
    }

    public GameObject GeneratePowerUp(Vector3 position, Vector2Int intPosition, PowerUp.Type type)
    {
        GameObject g = Instantiate(powerUpPrefab, position, Quaternion.identity);
        PowerUp p = g.GetComponent<PowerUp>();
        p.SetType(type);
        p.SetRowAndCol(intPosition);

        powerUps.Add(g.GetComponent<PowerUp>());
        return g;
    }
}
