﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PowerUp : MonoBehaviour
{
    private static List<Sprite> powerUpSpriteSheet = new List<Sprite>();

    private Type type;
    private int row = 0, col = 0;

    public bool isDestroyedNextTurn { get; private set; } = false;


    public enum Type
    {
        BONUSBALL = 0,
        HORIZONTAL_LINE,
        VERTICAL_LINE,
        BOTH_LINE,
        DINO,
        GOLD,
        STAR,

        // This should be the very last element, 
        // and should equal to the element count.
        COUNT
    }


    void Awake()
    {
        if(powerUpSpriteSheet.Count == 0)
        {
            powerUpSpriteSheet.AddRange(Resources.LoadAll<Sprite>("powerUp"));
        }
    }

    public void LiftDown(bool value)
    {
        Vector3 temp;
        if (value)
        {
            temp = Vector3.down;
        }
        else
        {
            temp = Vector3.up;
        }

        row -= (int)temp.y;
        transform.position += temp * SquareDataBase.main.squareSize;
    }

    public void SetRowAndCol(Vector2Int intPosition)
    {
        row = intPosition.x;
        col = intPosition.y;
    }

    public void SetType(Type type)
    {
        name = "powerup_" + (int)type;
        this.type = type;
        GetComponent<SpriteRenderer>().sprite = powerUpSpriteSheet[(int)type];
    }

    void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.gameObject.layer == 10)
        {
            switch (type)
            {
                case Type.BONUSBALL:
                    BonusBall();
                    goto default;
                case Type.GOLD:

                    goto default;
                case Type.STAR:

                    goto default;
                case Type.HORIZONTAL_LINE:
                    HorizontalPowerUp();
                    break;
                case Type.VERTICAL_LINE:
                    VerticalPowerUp();
                    break;
                case Type.BOTH_LINE:
                    HorizontalPowerUp();
                    VerticalPowerUp();
                    break;
                case Type.DINO:
                    if (collision.GetComponent<Ball>())
                    {
                        Dino(collision.GetComponent<Ball>());
                    }
                    break;
                // If the object has to be destroyed instantly, it goes to default.
                default:
                    Destroy(gameObject);
                    break;
            }

            isDestroyedNextTurn = true;
        }
    }

    private void BonusBall()
    {
        BallController.main.BonusBallPowerUp();
    }

    private void HorizontalPowerUp()
    {
        SquareDataBase.main.DamageRow(row);
    }

    private void VerticalPowerUp()
    {
        SquareDataBase.main.DamageColumn(col);
    }

    private void Dino(Ball ball)
    {
        Vector3 temp = new Vector3(Random.Range(-1f, 1f), Random.Range(.3f, 1f), 0);

        ball.SetVelocity(temp.normalized);
    }
}
