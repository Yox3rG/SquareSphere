﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "map", menuName = "ScriptableObject/MapObject", order = 1)]
public class MapObject : ScriptableObject
{
    public int row = 10, col = 10;

    public int[][] objects;
    public Vector2[][] vectors;

    public string name = "default";
}
