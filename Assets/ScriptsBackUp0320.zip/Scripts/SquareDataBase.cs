﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class SquareDataBase : MonoBehaviour
{
    public static SquareDataBase main { get; private set; } = null;

    public GameObject squarePrefab;
    public GameObject trianglePrefab;

    // Gameplay Properties.
    private int maxRoundCount = 5;
    private int currentRound = 0;


    // Generator Properties.
    private bool hasTriangles = false;

    private int currentId = 0; // Used in GenerateBlock.

    public float squareSize { get; private set; } = .55f; // Set in Awake again.
    private float sideSize = .125f / 2;

    private int mapSeed = 0;
    private int rows = 14, cols = 10;
    private int emptyRows = 6;

    private int minHp = 10;
    private int maxHp = 30;
    // This is a percentage in an integer, measured against highestSpawnInt (spawnChance / highestSpawnInt).
    // For example, a chance of (float)0.555f (=55.5%) is equvivalent to (int)555 in this case.
    private int spawnChance = 500;          // Chance of something.
    private int triangleSpawnChance = 100;  // If something, chance of triangle.
    private int powerupSpawnChance = 10;    // If something, chance of powerup.
    private int highestSpawnInt = 1000;
    

    // Database parts.
    private Random.State squareState;
    private Random.State hpState;

    private Vector3 startPosition;
    private Square[,] squares;
    

    void Awake()
    {
        if(main == null)
        {
            main = this;
        }

        squareSize = squarePrefab.GetComponent<BoxCollider2D>().size.x;

        // Hardcoded version in use atm.
        //startPosition = new Vector3(-Camera.main.orthographicSize * Camera.main.aspect + squareSize / 2 + sideSize, Camera.main.orthographicSize - squareSize / 2 - sideSize, 0);
        startPosition = new Vector3(-Camera.main.orthographicSize * Camera.main.aspect + squareSize / 2 + sideSize, 3.44f, 0);

        squares = new Square[rows, cols];
    }
    
    void Start()
    {
        if (Menu.main)
        {
            mapSeed = Menu.main.GetCurrentLvl();
        }
        else
        {
            mapSeed = 0;
        }

        hasTriangles = true;
        GenerateSquares(mapSeed);
    }

    public void NextRound()
    {
        if (SquaresLeft() == 0 && maxRoundCount == currentRound)
        {
            Victory();
        }
        else
        {
            LiftRows();
            PowerUpDataBase.main.NextRound();
            if(maxRoundCount > currentRound)
            {
                GenerateRow(0);
                currentRound++;
            }
        }
    }

    public void DamageRow(int row)
    {
        int i = row;

        for(int j = 0; j < cols; j++)
        {
            if(squares[i, j] != null)
            {
                squares[i, j].TakeDmg(1);
            }
        }
    }

    public void DamageColumn(int col)
    {
        int j = col;

        for (int i = 0; i < rows; i++)
        {
            if (squares[i, j] != null)
            {
                squares[i, j].TakeDmg(1);
            }
        }
    }

    // The seed determines the exact layout of the level.
    private void GenerateSquares(int seed)
    {
        Random.InitState(seed);
        squareState = Random.state;
        hpState = Random.state;
        
        for (int i = rows - emptyRows; i >= 0; i--)
        {
            GenerateRow(i);
        }
    }

    private void LiftRows()
    {
        int lastSafeRow = rows - 2;
        for (int j = 0; j < cols; j++)
        {
            if(squares[lastSafeRow, j] != null)
            {
                Defeat();
                break;
            }
        }
        for (int i = rows - 2; i >= 0; i--)
        {
            for (int j = 0; j < cols; j++)
            {
                if (squares[i, j] != null)
                {
                    squares[i, j].transform.position -= Vector3.up * squareSize;
                    squares[i, j].ResetTextPosition();

                    squares[i + 1, j] = squares[i, j];
                    squares[i, j] = null;
                }
            }
        }
    }

    private void GenerateRow(int row)
    {
        Random.state = squareState;

        for (int j = 0; j < cols; j++)
        {
            if (Random.Range(0, highestSpawnInt) < spawnChance)
            {
                Vector3 pos = startPosition + new Vector3(j, -row) * squareSize;
                GameObject g = null;

                if(Random.Range(0, highestSpawnInt) < powerupSpawnChance)
                {
                    PowerUpDataBase.main.GeneratePowerUpRandom(pos, new Vector2Int(row, j));
                }
                else if (hasTriangles && Random.Range(0, highestSpawnInt) < triangleSpawnChance)
                {
                    g = GenerateTriangle(pos);
                }
                else
                {
                    g = GenerateSquare(pos);
                }

                if(g != null)
                {
                    squares[row, j] = g.GetComponent<Square>();
                }
            }
            else
            {
                squares[row, j] = null;
            }
        }
        squareState = Random.state;

        Random.state = hpState;

        for (int j = 0; j < cols; j++)
        {
            if (squares[row, j] != null)
            {
                squares[row, j].SetMaxHp(Random.Range(minHp, maxHp));
                squares[row, j].ResetTextPosition();
            }
        }
        hpState = Random.state;
    }

    private GameObject GenerateSquare(Vector3 position)
    {
        GameObject g = GenerateBlock(squarePrefab, position);

        return g;
    }

    private GameObject GenerateTriangle(Vector3 position)
    {
        GameObject g = GenerateBlock(trianglePrefab, position);

        Triangle t = g.GetComponent<Triangle>();
        int orientation = Random.Range(0, 4);
        t.SetOrientationAndOffset(orientation);
        t.ResetTextPosition();

        return g;
    }

    private GameObject GenerateBlock(GameObject prefab, Vector3 position)
    {
        GameObject g = Instantiate(prefab, position, Quaternion.identity);
        g.name = prefab.name + currentId++;

        Text text = TextGenerator.main.Generate(g.transform.position);
        g.GetComponent<Square>().SetTextObject(text.GetComponent<Text>());

        return g;
    }

    private int SquaresLeft()
    {
        int count = 0;
        foreach(Square s in squares)
        {
            if(s != null)
            {
                count++;
            }
        }

        return count;
    }

    private void Victory()
    {
        Debug.Log("You won!");

        GamePlayMenu.main.GameOverPanel(true, true);
    }

    private void Defeat()
    {
        Debug.Log("You lost.");

        GamePlayMenu.main.GameOverPanel(true, false);
    }
}
