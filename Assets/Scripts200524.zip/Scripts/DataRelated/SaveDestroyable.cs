﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class SaveDestroyable
{
    public int maxHp;

    public Color color;

    public SaveDestroyable(int maxHp, Color color)
    {
        this.maxHp = maxHp;
        this.color = color;
    }

    public SaveDestroyable(SaveDestroyable s) : this(s.maxHp, s.color) { }
}
