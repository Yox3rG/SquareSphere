﻿using System.IO;
using System.Collections.Generic;
using UnityEngine;

public class MapDataBase : MonoBehaviour
{
    public static MapDataBase main = null;

    private Map currentMap = new Map();

    // Created in Start.
    private Map defaultMap = new Map();

    private readonly string fileLocation = "maps";
    private string fileName = "default";
    private readonly string fileExtension = ".json";

    private string mapFolder;

    public bool IsTesting { get; private set; }
    public bool IsDefault { get; private set; }
    
    private int currentIndex = 0;

    void Awake()
    {
        if (main == null)
        {
            main = this;
            DontDestroyOnLoad(this);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    void Start()
    {
        // Setting up default (impossible) map.
        defaultMap = new Map();
        defaultMap.numberOfBalls = 1;
        defaultMap.lines = new List<SaveElementLine>();
        defaultMap.lines.Add(new SaveElementLine());
        defaultMap.lines[0].list = new List<SaveElement>();
        for(int i = 0; i < 10; i++)
        {
            defaultMap.lines[0].list.Add(new SaveElement(Element.Type.SQUARE, 0, i, new SaveDestroyable(6969, Color.black)));
        }

        mapFolder = Path.Combine(Application.persistentDataPath, fileLocation);
        if (!Directory.Exists(mapFolder))
        {
            Directory.CreateDirectory(mapFolder);
        }
    }

    void Update()
    {
    }

    

    public int GetNumberOfBalls()
    {
        if (Menu.main != null)
        {
            if (Menu.main.IsPreMadeMap() || IsTesting)
            {
                return currentMap.numberOfBalls;
            }
            else
            {
                // TODO: Set a real number of balls for generated maps.
                return Mathf.FloorToInt(Menu.main.GetCurrentLvl() * .1f + 15);
            }
        }
        return 10;
    }

    #region FileRelated
    public void LoadDefaultMap()
    {
        currentMap = defaultMap;
        // Remove this later..
        currentMap = new Map();
        currentIndex = 0;
    }

    public bool LoadMap()
    {
        return LoadMap(GetCurrentFilePath());
    }

    // These ( \/ /\ ) for some reason does not change the stored file name.. Something to consider later.
    private bool LoadMap(string filePath)
    {
        bool loadOK = SaveLoadHandlerJSON<Map>.Load(filePath, out currentMap);
        IsDefault = false;

        currentIndex = 0;

        if (!loadOK)
        {
            IsDefault = true;
            LoadDefaultMap();
        }

        return loadOK;
    }

    public string GetFileName()
    {
        return fileName;
    }

    public void SetFileName(string fileName)
    {
        this.fileName = fileName;
    }

    public string GetCurrentFilePath()
    {
        return Path.Combine(fileLocation, fileName + fileExtension);
    }

    public List<string> GetAvailableMapList()
    {
        List<string> fileNames = new List<string>();

        DirectoryInfo info = new DirectoryInfo(mapFolder);
        FileInfo[] files = info.GetFiles("*.json");

        foreach(FileInfo file in files)
        {
            fileNames.Add(Path.GetFileNameWithoutExtension(file.FullName));
        }

        return fileNames;
    }
    #endregion

    #region Map
    public void InitiateTesting()
    {
        IsTesting = true;
        LoadMap();
    }

    public void StopTesting()
    {
        IsTesting = false;
    }

    public List<SaveElement> GetNextLine()
    {
        if(currentIndex < currentMap.lines.Count)
        {
            Debug.Log("Row: " + currentIndex);
            return currentMap.lines[currentIndex++].list;
        }
        else
        {
            Debug.Log("Map over, Row: " + currentIndex);
            return new List<SaveElement>();
        }
    }

    public int GetMapLength()
    {
        return currentMap.lines.Count;
    }

    /*
    private void Test()
    {
        currentMap = new Map();
        for (int i = 0; i < 10; i++)
        {
            currentMap.lines.Add(new SaveElementLine());
            currentMap.lines[i].list.Add(new SaveElement(Element.Type.SQUARE, 1, 1));
            currentMap.lines[i].list.Add(new SaveElement(Element.Type.TRIANGLE_180, 3, 1));
            currentMap.lines[i].list.Add(new SaveElement(Element.Type.TRIANGLE_90, 4, 1));
                        
            currentMap.lines[i].list.Add(new SaveElement(Element.Type.POWERUP_BOTH_LINE, 1, 2));
        }
        currentIndex = 0;
    }
    */
    #endregion
}
