﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Profile
{
    public string name;

    public int level;
    public long experience;

    public long stars;
    public int gold;
    


    public List<byte> starsOnMaps;

    public Profile()
    {
        name = "";

        level = 0;
        experience = 0;
        stars = 0;
        gold = 0;
        
        starsOnMaps = new List<byte>();
    }
}
