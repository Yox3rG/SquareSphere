﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ElementHandler : MonoBehaviour
{
    public static ElementHandler main { get; private set; } = null;

    public GameObject squarePrefab;
    public GameObject trianglePrefab;
    public GameObject powerUpPrefab;


    public float squareSize { get; protected set; } = .55f;
    public float sideSize { get; protected set; } = .125f / 2;

    private int currentId = 0; // Used in GenerateBlock.


    void Awake()
    {
        if(main == null)
        {
            main = this;
        }

        if (squarePrefab.GetComponent<BoxCollider2D>())
        {
            squareSize = squarePrefab.GetComponent<BoxCollider2D>().size.x;
        }
        currentId = 0;
    }

    public Element DeserializeAt(SaveElement saveElement, Vector3 position)
    {
        Element temp = Deserialize(saveElement);
        temp.transform.position = position;
        if (Element.IsDestroyable(saveElement.type))
        {
            ((Square)temp).ResetTextPosition();
        }
        return temp;
    }

    public Element Deserialize(SaveElement saveElement)
    {
        GameObject g = null;
        switch (saveElement.type)
        {
            case Element.Type.SQUARE:
                g = GenerateSquare();
                break;
            case Element.Type.TRIANGLE_0:
                g = GenerateTriangle(0);
                break;
            case Element.Type.TRIANGLE_90:
                g = GenerateTriangle(1);
                break;
            case Element.Type.TRIANGLE_180:
                g = GenerateTriangle(2);
                break;
            case Element.Type.TRIANGLE_270:
                g = GenerateTriangle(3);
                break;
                // HACK: Create bomb and shield prefab.
            case Element.Type.BOMB:
                g = GenerateSquare();
                break;
            case Element.Type.SHIELD:
                g = GenerateSquare();
                break;
            default:
                break;
        }

        if(g != null)
        {
            Square s = g.GetComponent<Square>();

            s.SetMaxHp(saveElement.destroyable.maxHp);
            s.ResetTextPosition();
            s.SetColor(saveElement.destroyable.color);
        }
        else if (Element.IsPowerUp(saveElement.type))
        {
            g = GeneratePowerUp(saveElement.type);
        }

        Element e = g.GetComponent<Element>();
        e.SetRowAndCol(saveElement.row, saveElement.col);
        e.SetType(saveElement.type);

        return e;
    }

    public SaveElement Serialize(Element element)
    {
        SaveElement saveElement = new SaveElement(element.type, element.row, element.col);
        if(element.IsDestroyable())
        {
            Square s = (Square)element;
            saveElement.destroyable = new SaveDestroyable(s.hp, s.color);
        }
        return saveElement;
    }

    public Element.Type GenerateTriangleTypeRandomly()
    {
        // There might be a better way to do this than hard coding.
        int orientation = Random.Range(1, 5);
        Element.Type type = (Element.Type)orientation;

        return type;
    }

    public Element.Type GeneratePowerUpTypeRandomly()
    {
        Element.Type type = (Element.Type)Random.Range(Element.powerupStart, Element.powerupEnd);

        return type;
    }

    #region GeneratePrefab
    private GameObject GenerateSquare()
    {
        GameObject g = GeneratePrefabWithHP(squarePrefab);

        return g;
    }

    private GameObject GenerateTriangle(int orientation)
    {
        GameObject g = GeneratePrefabWithHP(trianglePrefab);

        Triangle t = g.GetComponent<Triangle>();
        t.SetOrientationAndOffset(orientation);
        t.ResetTextPosition();

        return g;
    }

    private GameObject GeneratePrefabWithHP(GameObject prefab)
    {
        GameObject g = Instantiate(prefab, Vector3.zero, Quaternion.identity);
        g.name = prefab.name + "_" + currentId++;

        Text text = TextGenerator.main.Generate(g.transform.position);
        g.GetComponent<Square>().SetTextObject(text.GetComponent<Text>());

        return g;
    }

    private GameObject GeneratePowerUp(Element.Type type)
    {
        GameObject g = Instantiate(powerUpPrefab, Vector3.zero, Quaternion.identity);
        return g;
    }
    #endregion
}
