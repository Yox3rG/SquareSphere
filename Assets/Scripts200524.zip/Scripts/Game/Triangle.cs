﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Triangle : Square
{
    private float offsetAmout = .1f;

    private Vector3 offset;

    void Awake()
    {
    }

    public override void SetMaxHp(int hp)
    {
        base.SetMaxHp(hp);
    }

    public override void ResetTextPosition()
    {
        TextGenerator.main.Move(text.gameObject, transform.position + offset);
    }

    public void SetOrientationAndOffset(int orientation)
    {
        SetOrientation(orientation);

        offset = findOffset(transform.rotation.eulerAngles.z) * offsetAmout;
    }

    private void SetOrientation(int orientation)
    {
        transform.eulerAngles = new Vector3(0, 0, orientation * 90f);
    }

    private Vector3 findOffset(float degrees)
    {
        int rotation = Mathf.FloorToInt(degrees);
        Vector3 offset;

        switch (rotation)
        {
            case 0:
                offset = new Vector3(1, 1);
                break;
            case 270:
                offset = new Vector3(1, -1);
                break;
            case 180:
                offset = new Vector3(-1, -1);
                break;
            case 90:
                offset = new Vector3(-1, 1);
                break;
            default:
                offset = Vector3.zero;
                break;
        }

        return offset;
    }
}
