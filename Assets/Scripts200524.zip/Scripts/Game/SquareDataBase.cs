﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SquareDataBase : MonoBehaviour
{
    public static SquareDataBase main { get; private set; } = null;

    public LastRowWarning warning;

    // Gameplay Properties.
    private int maxRoundCount = 5;
    private int currentRound = 0;


    // Generator Properties.
    private bool generateFromData = false;
    private bool hasTriangles = false;

    private int destroyablesGenerated = 0;


    private const int rows = 14, cols = 10;
    private int emptyRows = 5;
    private int mapSeed = 0;

    private int minHp = 10;
    private int maxHp = 30;
    // This is a percentage in an integer, measured against highestSpawnInt (spawnChance / highestSpawnInt).
    // For example, a chance of (float)0.555f (=55.5%) is equvivalent to (int)555 in this case.
    private int spawnChance = 500;          // Chance of something.
    private int triangleSpawnChance = 100;  // If something, chance of triangle.
    private int powerupSpawnChance = 10;    // If something, chance of powerup.
    private int highestSpawnInt = 1000;

    private List<Color32> color32s;

    // Database parts.
    private Random.State elementSate;
    private Random.State hpState;
    private Random.State colorState;

    private float squareSize;
    private Vector3 startPosition;
    private Element[,] elements;



    void Awake()
    {
        if(main == null)
        {
            main = this;
        }

        // Hardcoded version in use atm.
        //startPosition = new Vector3(-Camera.main.orthographicSize * Camera.main.aspect + squareSize / 2 + sideSize, Camera.main.orthographicSize - squareSize / 2 - sideSize, 0);

        elements = new Element[rows, cols];
    }
    
    void Start()
    {
        squareSize = ElementHandler.main.squareSize;
        float sideSize = ElementHandler.main.sideSize;
        startPosition = new Vector3(-Camera.main.orthographicSize * Camera.main.aspect + squareSize / 2 + sideSize, 3.44f, 0);
        color32s = Palette.GetDefaultColors();

        // If we launched the testing from the Map Creator.
        if (MapDataBase.main != null && MapDataBase.main.IsTesting)
        {
            GenerateSquaresFromData();
        }
        // Regular method of identifying the map.
        else
        {
            object resultId;
            if (Menu.main != null)
            {
                generateFromData = Menu.main.IsPreMadeMap(out resultId);
            }
            else
            {
                generateFromData = false;
                resultId = (int)0;
            }

            if (!generateFromData)
            {
                if (Menu.main && resultId.GetType() == typeof(int))
                {
                    mapSeed = (int)resultId;
                }
                else
                {
                    mapSeed = 0;
                }

                hasTriangles = true;
                GenerateSquares(mapSeed);
            }
            else
            {
                if (resultId.GetType() == typeof(string))
                {
                    MapDataBase.main.SetFileName((string)resultId);
                    if (!MapDataBase.main.LoadMap())
                    {
                        MapDataBase.main.LoadDefaultMap();
                    }
                }
                GenerateSquaresFromData();
            }
        }
    }

    #region PowerUpRelated
    // Actual powerups.
    public void DamageRow(int row)
    {
        int i = row;

        for (int j = 0; j < cols; j++)
        {
            if (elements[i, j] != null && elements[i, j].IsDestroyable())
            {
                SquareFrom(elements[i, j]).TakeDmg(1);
            }
        }
    }

    public void DamageColumn(int col)
    {
        int j = col;

        for (int i = 0; i < rows; i++)
        {
            if (elements[i, j] != null && elements[i, j].IsDestroyable())
            {
                SquareFrom(elements[i, j]).TakeDmg(1);
            }
        }
    }

    // Powerup behaviour.
    // HACK: not optimal destroying of powerups
    private void DestroyUsedPowerUps()
    {
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                if(elements[i, j] is PowerUp p)
                {
                    if(p != null && p.isDestroyedNextTurn)
                    {
                        Destroy(p.gameObject);
                    }
                }
            }
        }
    }
    #endregion

    #region GeneratingTheMap
    // The seed determines the exact layout of the level.
    private void GenerateSquares(int seed)
    {
        Random.InitState(seed);
        elementSate = Random.state;
        hpState = Random.state;
        colorState = Random.state;

        for (int i = rows - emptyRows - 1; i >= 0; i--)
        {
            GenerateRow(i);
        }
    }

    private void GenerateSquaresFromData()
    {
        maxRoundCount = MapDataBase.main.GetMapLength() - rows + emptyRows;

        for (int i = rows - emptyRows - 1; (i >= 0) && (i >= -maxRoundCount); i--)
        {
            GenerateRowFromData(i, MapDataBase.main.GetNextLine());
        }
    }

    private void GenerateRow(int row)
    {
        Random.state = elementSate;

        for (int j = 0; j < cols; j++)
        {
            if (Random.Range(0, highestSpawnInt) < spawnChance)
            {
                Vector3 pos = startPosition + new Vector3(j, -row) * squareSize;
                Element tempElement = null;

                if(Random.Range(0, highestSpawnInt) < powerupSpawnChance)
                {
                    tempElement = GenerateRandomPowerUpAt(pos, row, j);
                }
                else if (hasTriangles && Random.Range(0, highestSpawnInt) < triangleSpawnChance)
                {

                    tempElement = GenerateRandomTriangleAt(pos, row, j);
                }
                else
                {
                    tempElement = GenerateRandomSquareAt(pos, row, j);
                }
                elements[row, j] = tempElement;

                if (tempElement.IsDestroyable())
                {
                    destroyablesGenerated++;
                }
            }
            else
            {
                elements[row, j] = null;
            }
        }
        elementSate = Random.state;

        // Hp generation moved into the elementGeneration process.
        // The new procedure changes the Random.state rapidly, might be a bad idea.
        /*
        Random.state = hpState;
        for (int j = 0; j < cols; j++)
        {
            if (IsDestroyableAndNotNull(elements[row, j]))
            {
                SquareFrom(elements[row, j]).SetMaxHp(GenerateRandomHp());
                SquareFrom(elements[row, j]).ResetTextPosition();
            }
        }
        hpState = Random.state;
         */
    }

    private void GenerateRowFromData(int row, List<SaveElement> saveElements)
    {
        Debug.Log("GenerateRowFromData, elementcount: " + saveElements.Count);
        foreach (SaveElement s in saveElements)
        {
            Vector3 pos = startPosition + new Vector3(s.col, -row) * squareSize;

            elements[row, s.col] = ElementHandler.main.DeserializeAt(s, pos);

            if(elements[row, s.col].IsDestroyable())
            {
                destroyablesGenerated++;
            }
        }
    }
    #endregion

    #region NewRandomElementGenerationBackEnd
    private Element GenerateRandomPowerUpAt(Vector3 position, int row, int col)
    {
        Element.Type type = ElementHandler.main.GeneratePowerUpTypeRandomly();
        SaveElement se = new SaveElement(type, row, col);
        return ElementHandler.main.DeserializeAt(se, position);
    }

    private Element GenerateRandomTriangleAt(Vector3 position, int row, int col)
    {
        Element.Type type = ElementHandler.main.GenerateTriangleTypeRandomly();
        SaveElement se = new SaveElement(type, row, col, new SaveDestroyable(GenerateRandomHp(), GenerateRandomColor()));
        return ElementHandler.main.DeserializeAt(se, position);
    }

    private Element GenerateRandomSquareAt(Vector3 position, int row, int col)
    {
        SaveElement se = new SaveElement(Element.Type.SQUARE, row, col, new SaveDestroyable(GenerateRandomHp(), GenerateRandomColor()));
        return ElementHandler.main.DeserializeAt(se, position);
    }

    // This is an old part, and I'm not sure anymore about why states have to be separated, but here we go.
    private int GenerateRandomHp()
    {
        // Element generation should not be interrupted.
        Random.State oldState = Random.state;

        Random.state = hpState;
        int temp = Random.Range(minHp, maxHp);
        hpState = Random.state;

        Random.state = oldState;
        return temp;
    }

    private Color32 GenerateRandomColor()
    {
        // Element generation should not be interrupted.
        Random.State oldState = Random.state;

        Color32 temp = Color.white;

        Random.state = colorState;
        int index = Random.Range(0, color32s.Count - 1);
        temp = color32s[index];
        colorState = Random.state;

        Random.state = oldState;
        return temp;
    }
    #endregion

    public void NextRound()
    {
        if (SquaresLeft() == 0 && maxRoundCount <= currentRound)
        {
            HideWarning();
            Victory();
        }
        else
        {
            DestroyUsedPowerUps();
            LiftRows();
            if (maxRoundCount > currentRound)
            {
                if (generateFromData || (MapDataBase.main != null && MapDataBase.main.IsTesting))
                {
                    GenerateRowFromData(0, MapDataBase.main.GetNextLine());
                }
                else
                {
                    GenerateRow(0);
                }
            }
            currentRound++;
        }
    }

    public int GetCurrentRound()
    {
        return currentRound;
    }

    public int GetVisibleDestroyableCount()
    {
        return destroyablesGenerated;
    }

    // Checks if DEFEAT
    // Checks if the WARNING has to be displayed
    private void LiftRows()
    {
        int lastSafeRow = rows - 2;
        int overLastSafeRow = lastSafeRow - 1;

        if(IsDestroyableInRow(overLastSafeRow))
        {
            ShowWarning();
        }
        else
        {
            HideWarning();
        }

        if (IsDestroyableInRow(lastSafeRow))
        {
            Defeat();
            HideWarning();
        }

        for (int i = rows - 2; i >= 0; i--)
        {
            for (int j = 0; j < cols; j++)
            {
                if (elements[i, j] != null)
                {
                    elements[i, j].transform.position += Vector3.down * squareSize;
                    if (elements[i, j].IsDestroyable())
                    {
                        SquareFrom(elements[i, j]).ResetTextPosition();
                    }

                    elements[i + 1, j] = elements[i, j];
                    elements[i, j] = null;

                    elements[i + 1, j].SetRowAndCol(i + 1, j);
                }
            }
        }
    }

    private bool IsDestroyableInRow(int index)
    {
        for (int j = 0; j < cols; j++)
        {
            if (elements[index, j] != null && elements[index, j].IsDestroyable())
            {
                return true;
            }
        }
        return false;
    }

    private int SquaresLeft()
    {
        int count = 0;
        foreach(Element e in elements)
        {
            if (IsDestroyableAndNotNull(e))
            {
                count++;
            }
        }

        return count;
    }

    private bool IsDestroyableAndNotNull(Element element)
    {
        if(element != null && element.IsDestroyable())
        {
            return true;
        }
        return false;
    }

    private Square SquareFrom(Element element)
    {
        return (Square)element;
    }

    public void ShowWarning()
    {
        warning.Show(true);
    }

    public void HideWarning()
    {
        warning.Show(false);
    }

    private void Victory()
    {
        Debug.Log("You won!");

        if (MapDataBase.main.IsTesting)
        {
            ReturnToMapEditor();
        }
        else
        {
            if(Menu.main.GetCurrentLvl() == ProfileDataBase.main.GetLastPlayableMap())
            {                                                      // #unintendedboobs
            // TODO: The score system is not yet present, remove the "1" (   \/   ) and replace it with something real later.
                ProfileDataBase.main.CompleteLevel(Menu.main.GetCurrentLvl(), 1);
                Menu.main.RefreshLastShownLevelButtons();
            }
            else
            {
                ProfileDataBase.main.CompleteLevel(Menu.main.GetCurrentLvl(), 2);
                Menu.main.UpdateStarAmountOnCurrentLevelButton();
            }
            GamePlayMenu.main.GameOverPanel(true, true);
        }
    }

    private void Defeat()
    {
        Debug.Log("You lost.");

        if (MapDataBase.main.IsTesting)
        {
            ReturnToMapEditor();
        }
        else
        {
            ProfileDataBase.main?.StatIncreaseDeath();
            GamePlayMenu.main.GameOverPanel(true, false);
        }
    }

    private void ReturnToMapEditor()
    {
        Menu.main.SetMapEditorScreen();
    }
}
