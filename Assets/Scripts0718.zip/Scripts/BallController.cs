﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class BallController : MonoBehaviour
{
    public static BallController main { get; private set; } = null;

    public GameObject ballPrefab;
    public GameObject particlePrefab;

    public Color textColor = Color.cyan;
    public GameObject line;


    private GameObject newPositionHolder;
    private SpriteRenderer sr;
    private LineRenderer lineRenderer;
    private Text text;

    private int fallenBalls = 0;
    private int maxNumOfBalls = 25;
    private int bonusBalls = 0;
    private int newBonusBalls = 0;
    private int numOfBalls = 1;

    private List<Ball> balls = new List<Ball>();


    private bool isRolling = false;
    private float nextTime;
    private const float cooldown = .05f;

    private float rollSpeedUpStart = 0f;
    private const float maxSpeedUpThreshold = 7f;
    private float currentSpeedUpThreshold = maxSpeedUpThreshold;
    private const float speedUpThresholdDivider = 2f;
    private const int maxSpeedUpCount = 1;
    private int speedUpCountLeft = maxSpeedUpCount;
    private const float speedUpAmount = 4f;
    private float textOffset = .2f;


    private float minTargetDegree = 10;
    // Automatically set in Start(), calculated from minTargetDegree.
    private float minTargetX;
    private float minTargetY;

    private float lineLength = 3f;

    private Vector3 target;
    private Vector3 targetDirection;
    private Vector3 newPosition;

    private void Awake()
    {
        if (main == null)
        {
            main = this;
        }
    }

    void Start()
    {
        isRolling = false;
        newPosition = transform.position;

        sr = GetComponent<SpriteRenderer>();

        // Set the ballgenerator's sprite, to match the ball.
        sr.sprite = ballPrefab.GetComponent<SpriteRenderer>().sprite;

        // Set up the placeholder for fallen balls.
        newPositionHolder = new GameObject();
        newPositionHolder.transform.position = newPosition;
        newPositionHolder.AddComponent<SpriteRenderer>().sprite = sr.sprite;

        // Add the particle effect. (Comment this line to disable)
        //GameObject g = Instantiate(particlePrefab, newPositionHolder.transform, false);

        newPositionHolder.SetActive(false);


        // Generate text for the number of balls.
        text = TextGenerator.main.Generate(transform.position + Vector3.up * textOffset, textColor);
        SetText();

        minTargetY = Mathf.Sin(Mathf.Deg2Rad * minTargetDegree);
        minTargetX = Mathf.Cos(Mathf.Deg2Rad * minTargetDegree);

        lineRenderer = line.GetComponent<LineRenderer>();
        DisableLine();
    }


    void Update()
    {
        if (isRolling)
        {
            nextTime -= Time.deltaTime;
            if(rollSpeedUpStart < Time.time && speedUpCountLeft > 0)
            {
                SpeedUpTimeAndSetThreshold(speedUpThresholdDivider);
            }
            if(nextTime < 0 && numOfBalls > 0)
            {
                SendBallTo(targetDirection);
                numOfBalls--;
                nextTime = cooldown;

                if(numOfBalls <= 0)
                {
                    sr.enabled = false;
                    //transform.position = newPosition;
                }
            }

            if (Input.GetKeyDown(KeyCode.C))
            {
                StopRolling();
            }
        }
        else
        {
            if (isTargeting())
            {
                HandleMouseInteraction();
                
                HandleTouchInteraction();
            }
            else
            {
                DisableLine();
            }
        }

        if (Input.GetKey(KeyCode.T))
        {
            Time.timeScale = 1f;
        }
        if (Input.GetKeyUp(KeyCode.T))
        {
            Time.timeScale = 0;
        }
    }

    public void FirstBallFell(Vector3 position)
    {
        newPosition = new Vector3(position.x, transform.position.y);

        if(numOfBalls <= 0)
        {
            transform.position = newPosition;
        }
        SetHolderActive(true);
    }

    public Vector3 GetNewLocation()
    {
        return newPosition;
    }

    public void BallFellDown()
    {
        if (++fallenBalls == maxNumOfBalls + bonusBalls)
        {
            StopRolling();
        }
    }


    private void SetText()
    {
        text.text = maxNumOfBalls + " + " + bonusBalls;
    }

    private void SetText(Vector3 position)
    {
        TextGenerator.main.Move(text.gameObject, position);
        SetText();
    }

    private void SetHolderActive(bool value)
    {
        newPositionHolder.transform.position = newPosition;
        newPositionHolder.SetActive(value);
    }

    private void SetSpeedUpSettingsToDefault()
    {
        currentSpeedUpThreshold = maxSpeedUpThreshold;
        speedUpCountLeft = maxSpeedUpCount;

        rollSpeedUpStart = Time.time + currentSpeedUpThreshold;
    }
    
    private void SpeedUpTimeAndSetThreshold(float divider)
    {
        Time.timeScale *= speedUpAmount;

        currentSpeedUpThreshold /= divider;
        speedUpCountLeft--;

        rollSpeedUpStart = Time.time + currentSpeedUpThreshold;
    }

    private void StartRolling(Vector3 screenPosition)
    {
        target = Camera.main.ScreenToWorldPoint(screenPosition);
        target.z = 0;
        targetDirection = CalculateRealVelocity(target);

        isRolling = true;
        nextTime = 0;
        numOfBalls = maxNumOfBalls + bonusBalls;
        fallenBalls = 0;

        SetSpeedUpSettingsToDefault();

        text.enabled = false;

        BallBasket.main.GameIsRolling();
    }

    public void StopRolling()
    {
        if (isRolling)
        {
            isRolling = false;
            Time.timeScale = 1;

            SquareDataBase.main.NextRound();
            BallBasket.main.GameStoppedRolling();

            transform.position = newPosition;
            sr.enabled = true;
            SetHolderActive(false);
            CollectBalls();

            bonusBalls += newBonusBalls;
            newBonusBalls = 0;

            SetText(newPosition + Vector3.up * textOffset);
            text.enabled = true;
        }
    }

    #region Targeting
    private void HandleTouchInteraction()
    {
        if (Input.touchCount > 0)
        {
            Touch touch = Input.GetTouch(0);

            if (touch.phase == TouchPhase.Moved)
            {
                target = Camera.main.ScreenToWorldPoint(touch.position);
                target.z = 0;
                DrawLineTo(CalculateRealVelocity(target));
            }

            if (touch.phase == TouchPhase.Ended)
            {
                DisableLine();
                StartRolling(touch.position);
            }
        }
    }

    private void HandleMouseInteraction()
    {
        if (Input.GetMouseButton(0))
        {
            target = Camera.main.ScreenToWorldPoint(Input.mousePosition);
            target.z = 0;
            DrawLineTo(CalculateRealVelocity(target));
            Debug.DrawRay(transform.position, CalculateRealVelocity(target), Color.cyan);
        }
        else if (Input.GetMouseButtonUp(0))
        {
            DisableLine();
            StartRolling(Input.mousePosition);
        }
    }

    private void DisableLine()
    {
        DrawLineTo(Vector3.zero);
    }

    private void DrawLineTo(Vector3 targetDirection)
    {
        lineRenderer.SetPosition(1, targetDirection * lineLength);
    }

    private bool isTargeting()
    {
        // Testing touch input here atm.
        bool value = isTargetingTouch();

        if(!EventSystem.current.IsPointerOverGameObject(-1))
        {
            value = true;
        }
        /*
        if (Input.touchCount > 0 && !EventSystem.current.IsPointerOverGameObject(Input.GetTouch(0).fingerId))
        {
            value = true;
        }
        */
        if ((EventSystem.current.currentSelectedGameObject != null && EventSystem.current.currentSelectedGameObject.layer == 11))
        {
            value = true;
        }
        return value;
    }

    private bool isTargetingTouch()
    {
        if(Input.touchCount > 0)
        {
            PointerEventData pointerEventData = new PointerEventData(EventSystem.current);
            pointerEventData.position = Input.GetTouch(0).position;
            List<RaycastResult> results = new List<RaycastResult>();

            EventSystem.current.RaycastAll(pointerEventData, results);
            return results.Count == 0;
        }
        else
        {
            return false;
        }
    }
    #endregion

    #region PowerUpRelated
    public void BonusBallPowerUp()
    {
        newBonusBalls++;
    }
    #endregion

    private Vector3 CalculateRealVelocity(Vector3 target)
    {
        Vector3 velocity = (target - transform.position).normalized;

        if (velocity.y < minTargetY)
        {
            velocity.x = Mathf.Sign(velocity.x) * minTargetX;
            velocity.y = minTargetY;
        }

        return velocity;
    }

    // The target and the transform.position should have their z = 0;
    private void SendBallTo(Vector3 direction)
    {
        CreateBall().SetVelocity(direction);
    }

    private Ball CreateBall()
    {
        GameObject g = Instantiate(ballPrefab, transform.position, Quaternion.identity);
        Ball ball = g.GetComponent<Ball>();
        balls.Add(ball);

        return ball;
    }
    
    private void CollectBalls()
    {
        foreach(Ball b in balls)
        {
            if(b != null)
            {
                b.Return();
            }
        }
        balls.Clear();
    }
}
