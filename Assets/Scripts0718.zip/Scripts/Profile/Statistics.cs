﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Statistics
{
    // Profile related;
    public long experienceGained;
    public long goldEarned;


    // Gameplay related.
    public long ballsFired;
    public long blocksBroken;
    public long attachmentsBroken;
    public long powerUpsPickedUp;

    public int deathCount;
}
