﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Palette
{
    public List<Color32> colors;

    public static Palette Default { get; private set; } = new Palette(new Color32[]
    {
        new Color32(255, 255, 255, 255),
        new Color32(0, 0, 255, 255),
        new Color32(0, 255, 0, 255),
        new Color32(255, 0, 0, 255),
        new Color32(255, 255, 255, 255),
        new Color32(255, 255, 255, 255),
        new Color32(255, 255, 255, 255),
        new Color32(255, 255, 255, 255),
        new Color32(255, 255, 255, 255),
        new Color32(255, 255, 255, 255),
        new Color32(255, 255, 255, 255)
    });
    
    public Palette()
    {
        colors = new List<Color32>();
    }

    public Palette(IEnumerable<Color32> colors)
    {
        this.colors = new List<Color32>(colors);
    }
}
