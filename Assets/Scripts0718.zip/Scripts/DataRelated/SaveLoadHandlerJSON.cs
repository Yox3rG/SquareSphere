﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

public class SaveLoadHandlerJSON<T>
{
    private static readonly string path = Application.persistentDataPath;



    public static bool Save(T data, string fileName)
    {
        string tempPath = Path.Combine(path, fileName);

        try
        {
            using (StreamWriter streamWriter = File.CreateText(tempPath))
            {
                string jsonString = JsonUtility.ToJson(data);
                streamWriter.Write(jsonString);
                Debug.Log("Saved succesfully");
                return true;
            }
        }
        catch (System.Exception e)
        {
            Debug.Log("File save error\n" + e.Message);
        }
        return false;
    }
    
    public static bool Load(string fileName, out T data)
    {
        string tempPath = Path.Combine(path, fileName);
        //BinaryFormatter binaryFormatter = new BinaryFormatter();
        //FileStream fileStream = File.Open(fileName, FileMode.Open);

        try
        {
            using (StreamReader streamReader = File.OpenText(tempPath))
            {
                string jsonString = streamReader.ReadToEnd();
                Debug.Log("Loaded succesfully");
                data = JsonUtility.FromJson<T>(jsonString);
                return true;
            }
        }
        catch (System.Exception e)
        {
            Debug.Log("File load error\n" + e.Message);
        }
        data = default;
        return false;
    }
}
