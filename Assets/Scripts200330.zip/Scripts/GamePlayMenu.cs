﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GamePlayMenu : MonoBehaviour
{
    public static GamePlayMenu main { get; private set; } = null;


    public GameObject gameplayPanel;
    public GameObject pausePanel;
    public GameObject gameEndPanel;

    public GameObject clearUI;
    public GameObject failUI;

    public Text txt_Lvl;
    public Text txt_Gold;

    void Awake()
    {
        if(main == null)
        {
            main = this;
        }
    }

    void Start()
    {
        if(ProfileDataBase.main != null)
        {
            txt_Gold.text = ProfileDataBase.main.GetCurrentGold().ToString();
        }
        else
        {
            txt_Gold.text = "69";
        }
    }

    public void Pause(bool value)
    {
        pausePanel.SetActive(value);
        if (value)
        {
            Time.timeScale = 0;
        }
        else
        {
            Time.timeScale = 1;
        }
    }

    public void GameOverPanel(bool visible, bool victory)
    {
        gameEndPanel.SetActive(visible);
        clearUI.SetActive(victory);
        failUI.SetActive(!victory);

        // Testing purposes.
        string temp = Menu.main == null ? "0" : Menu.main.GetCurrentLvl().ToString();
        txt_Lvl.text = "level " + temp;
    }

    public void LoadNextLevel()
    {
        if (Menu.main != null)
        {
            Menu.main.LevelOnClick(Menu.main.GetCurrentLvl() + 1);
        }
    }

    public void ResetLevel()
    {
        if(Menu.main != null)
        {
            Debug.Log(Menu.main.name);
            Menu.main.LevelOnClick(Menu.main.GetCurrentLvl());
        }
    }

    public void SetHomeScreen()
    {
        if (Menu.main != null)
        {
            if (MapDataBase.main != null && MapDataBase.main.IsTesting)
            {
                Menu.main.SetMapEditorScreen();
            }
            else
            {
                Menu.main.SetHomeScreen();
            }

        }
        else
        {
            // HACK : This is for editor only.
            if (MapDataBase.main != null && MapDataBase.main.IsTesting)
            {
                UnityEngine.SceneManagement.SceneManager.LoadScene(2);
            }
            else
            {
                UnityEngine.SceneManagement.SceneManager.LoadScene(0);
            }
        }
    }
}
