﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Statistics
{
    // Profile related;
    public long experienceGained;
    public long goldEarned;


    // Gameplay related.
    public int deathCount;


    public long ballsFired;
    public long blocksBroken;
    public int blocksBrokenOneRound;
    public long attachmentsBroken;
    public long powerUpsActivated;

    public int highestScore;
    public double timeSpent;
}
