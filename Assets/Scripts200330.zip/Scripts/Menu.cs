﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Linq;

public class Menu : MonoBehaviour
{
    public static Menu main { get; private set; }

    public const int MAP_TESTING_LVL = -696969;

    public GameObject canvas;
    public GameObject gameCanvas;

    // Used for the selected ball in the shop.
    public GameObject checkMark;
    private int checkMarkOffsetY = -100;
    // Colors for the different states of the buttons.
    private Color selectedColor;
    private Color lockedColor;
    private Color unlockedColor;

    // "Temporary" array for the star alignment.
    private string[] starNumberToName = new string[] { "L", "M", "R" };

    // Colors.
    private Color32 lvlFilledStarColor;
    private Color32 lvlEmptyStarColor;

    // Text.
    public Text goldText_Shop;
    public Text goldText_Profile;
    public Text starText_Profile;
    public Text nameText_Profile;
    public Text xpText_Profile;
    public Text lvlText_Profile;
    public Text statList_Profile;

    public InputField inf_changeName;
    public Button btn_changeName;

    // Panels.
    // Contains all the other ones except the last one, updated in Start()
    private GameObject[] panels;
    public GameObject menuPanel;
    public GameObject shopPanel;
    public GameObject settingsPanel;
    public GameObject profilePanel;
    // This one isn't truly a panel.
    public GameObject popupForBuyPanel;
    public GameObject popupForNameChange;

    // ScrollViews.
    public GameObject lvlScrollContent;
    public GameObject shopScrollContent;

    // Prefabs.
    public GameObject lvlPrefab;
    public GameObject shopPrefab;

    // GeneratedButtons.
    private List<GameObject> lvlButtons;
    private List<GameObject> shopButtons;

    private int currentSelectedBallToBuy = 0;

    private int currentLvl = 0;

    private LevelLayout levelLayout;
    

    void Awake()
    {
        if(main == null)
        {
            main = this;
            DontDestroyOnLoad(this);
            DontDestroyOnLoad(canvas);

            currentLvl = 0;
        }
        else
        {
            Destroy(canvas);
            Destroy(gameObject);
        }
    }

    void Start()
    {
        levelLayout = new LevelLayout(LevelLayout.LayoutType.DEFAULT);

        panels = new GameObject[] { menuPanel, shopPanel, profilePanel, settingsPanel };


        SetDefaultState();
    }

    // TODO: Save should probably be called more frequently.
    void OnApplicationQuit()
    {
        ProfileDataBase.main.SaveData();
    }

    void OnApplicationPause(bool pauseStatus)
    {
        ProfileDataBase.main.SaveData();
    }

    #region ButtonGeneration
    private void GenerateLvlPrefabs(int lvlCount)
    {
        lvlButtons = GeneratePrefabsWithOnclick(LevelOnClick, lvlCount, lvlPrefab, lvlScrollContent.transform);
    }

    private void GenerateShopPrefabs(int itemCount)
    {
        shopButtons = GeneratePrefabsWithOnclick(OnShopElementClick, itemCount, shopPrefab, shopScrollContent.transform);
    }

    private List<GameObject> GeneratePrefabsWithOnclick(System.Action<int> onclickFunc, int count, GameObject prefab, Transform parent)
    {
        List<GameObject> gameObjects = new List<GameObject>();
        for (int i = 0; i < count; i++)
        {
            GameObject g = Instantiate(prefab, parent);
            g.GetComponentInChildren<Text>(true).text = i.ToString();
            g.name = i.ToString();
            int iValue = i;
            g.GetComponent<Button>().onClick.AddListener(delegate { onclickFunc(iValue); });

            gameObjects.Add(g);
        }

        return gameObjects;
    }
    
    // HACK a lot of string compares here at find methods :thinking:
    private void ShowAllPlayableLevels(int from)
    {
        if (from < 0)
        {
            from = 0;
        }

        int i = from;
        int lastPlayableLevel = ProfileDataBase.main.GetLastPlayableMap();

        while (i < lastPlayableLevel)
        {
            lvlButtons[i].transform.Find("Locked").gameObject.SetActive(false);
            lvlButtons[i].transform.Find("Unlocked").gameObject.SetActive(true);
            for (int j = 0; j < ProfileDataBase.main.GetStarsOnMap(i); j++)
            {
                string currentTransformPath = "Unlocked/Stars/" + starNumberToName[j];
                lvlButtons[i].transform.Find(currentTransformPath).GetComponent<Image>().color = lvlFilledStarColor;
            }

            i++;
        }

        lvlButtons[i].transform.Find("Locked").gameObject.SetActive(false);
        lvlButtons[i].transform.Find("Unlocked").gameObject.SetActive(true);
    }
    #endregion

    #region ButtonOnClicks
    public void OnShopElementClick(int index)
    {
        //Debug.Log("Clicked on shop element : " + index);
        if (ProfileDataBase.main.IsBallUnLocked(index))
        {
            if (ProfileDataBase.main.GetSelectedBallIndex() == index)
            {
                // Clicking the selected ball shouldn't do anything, right?!
            }
            else
            {
                SelectBall(index);
            }
        }
        else
        {
            currentSelectedBallToBuy = index;
            EnableBuyingPopupWindow(index);
        }
    }

    public void LevelOnClick(int lvl)
    {
        if (ProfileDataBase.main.IsLevelPlayable(lvl))
        {
            currentLvl = lvl;
            SetGameScreen();
        }
        else
        {
            // TODO: Unplayable level onClick.
        }
    }

    public void BuyBallOnClick()
    {
        BuyBall(currentSelectedBallToBuy);
    }

    // HACK lot of debugging here, but these could have importance. (grammar?!)
    private void BuyBall(int index)
    {
        ProfileDataBase.PaymentResult result = ProfileDataBase.main.BuyBall(index);
        switch (result)
        {
        case ProfileDataBase.PaymentResult.SUCCESS:
                OnSuccessfulBallPurchase();
                Debug.Log("Ball payment: SUCCESS ");
            break;
        case ProfileDataBase.PaymentResult.NOT_ENOUGH_CURRENCY:
                Debug.Log("Ball payment: NOT_ENOUGH_CURRENCY ");
            break;
        // These in theory should never run. There is a problem if you see them...
        case ProfileDataBase.PaymentResult.ALREADY_PURCHASED:
                Debug.Log("Ball payment: ALREADY_PURCHASED ");
            break;
        case ProfileDataBase.PaymentResult.NO_SUCH_ITEM:
                Debug.Log("Ball payment: NO_SUCH_ITEM ");
            break;
        case ProfileDataBase.PaymentResult.UNSPECIFIED_ERROR:
            Debug.Log("Ball payment: UNSPECIFIED_ERROR ");
            break;

        }
    }

    public void DisableBuyingPopupWindow()
    {
        popupForBuyPanel.SetActive(false);
    }

    // This is not an onclick function (is also private), it is used in the OnShopElementClick().
    private void EnableBuyingPopupWindow(int clickedBallIndex)
    {
        popupForBuyPanel.SetActive(true);
        popupForBuyPanel.transform.Find("Panel").Find("Ball").GetComponent<Image>().sprite = ProfileDataBase.main.GetBallResource(clickedBallIndex);
    }

    // This neither is for onclick, in BuyBall().
    private void OnSuccessfulBallPurchase()
    {
        // Ball is selected in ProfileDataBase already.
        RefreshAllShownBallStates();
        DisableBuyingPopupWindow();
        RefreshShownGoldAmount();
        RefreshShownStats();
    }

    public void EnableNameChangePopupWindow()
    {
        popupForNameChange.SetActive(true);
    }

    public void DisableChangeNamePopupWindow()
    {
        popupForNameChange.SetActive(false);
    }

    public enum NamingError
    {
        NONE,
        TOO_LONG,
        NOT_ALLOWED_CHARACTERS
    }

    public void ChangeName()
    {
        string temp = inf_changeName.text;
        NamingError error = NamingError.NONE;

        if (IsNameCorrect(temp, out error))
        {
            ProfileDataBase.main.ChangeName(temp);
            RefreshShownName();
        }
        else
        {
            switch (error)
            {
                case NamingError.TOO_LONG:
                    Debug.Log("The name is too long");
                    break;
                case NamingError.NOT_ALLOWED_CHARACTERS:
                    Debug.Log("Not allowed characters used in name");
                    break;
            }
        }


    }
    #endregion

    private bool IsNameCorrect(string name, out NamingError error)
    {
        bool value = true;
        error = NamingError.NONE;

        if(name.Length >= 14)
        {
            error = NamingError.TOO_LONG;
            value = false;
        }

        return value;
    }

    private void ApplyTextureToShopPrefabs()
    {
        if (shopScrollContent.transform.childCount == ProfileDataBase.main.NumberOfBallResources())
        {
            for(int i = 0; i < shopButtons.Count; i++)
            {
                shopButtons[i].transform.Find("Ball").GetComponent<Image>().sprite = ProfileDataBase.main.GetBallResource(i);
            }

            /*
            int index = 0;
            foreach(Transform t in shopScrollContent.transform.Cast<Transform>().OrderBy(pref => System.Convert.ToInt32(pref.name)))
            {
                Debug.Log(t.name);
                t.Find("Ball").GetComponent<Image>().sprite = ProfileDataBase.main.GetBallResource(index);
                index++;
            }
            */
        }
        else
        {
            // TODO: Implement what happens if the shop for some reason has less or more prefabs than we have balls.
        }
    }

    #region ColoringButtonStates
    // The function does not care if the ball is selected or not, sets it unlocked or locked.
    private void SetShopPrefabColorNotSelected(int index)
    {
        if (ProfileDataBase.main.IsBallUnLocked(index))
        {
            shopButtons[index].transform.Find("Frame").GetComponent<Image>().color = unlockedColor;
            shopButtons[index].transform.Find("Price").gameObject.SetActive(false);
        }
        else
        {
            shopButtons[index].transform.Find("Frame").GetComponent<Image>().color = lockedColor;
            shopButtons[index].transform.Find("Price").GetComponent<Text>().text = ProfileDataBase.main.GetBallPrice(index).ToString();
        }
    }

    private void RefreshSelectedBallColor()
    {
        Transform selectedTransform = shopButtons[ProfileDataBase.main.GetSelectedBallIndex()].transform;

        selectedTransform.Find("Frame").GetComponent<Image>().color = selectedColor;

        checkMark.SetActive(true);
        checkMark.transform.SetParent(selectedTransform);
        //checkMark.GetComponent<RectTransform>().anchoredPosition = new Vector2(selectedTransform.position.x, selectedTransform.position.y + checkMarkOffsetY);
        checkMark.GetComponent<RectTransform>().anchoredPosition = new Vector2(0, checkMarkOffsetY);
    }

    private void RefreshAllShownBallStates()
    {
        for (int i = 0; i < shopButtons.Count; i++)
        {
            SetShopPrefabColorNotSelected(i);
        }
        RefreshSelectedBallColor();
    }
    #endregion

    #region RefreshValues
    private void SelectBall(int index)
    {
        SetShopPrefabColorNotSelected(ProfileDataBase.main.GetSelectedBallIndex());

        ProfileDataBase.main.SelectBall(index);
        RefreshSelectedBallColor();
    }

    public void UpdateStarAmountOnCurrentLevelButton()
    {
        int index = currentLvl;

        for (int j = 0; j < ProfileDataBase.main.GetStarsOnMap(index); j++)
        {
            string currentTransformPath = "Unlocked/Stars/" + starNumberToName[j];
            lvlButtons[index].transform.Find(currentTransformPath).GetComponent<Image>().color = lvlFilledStarColor;
        }
    }

    public void RefreshLastShownLevelButtons()
    {
        ShowAllPlayableLevels(ProfileDataBase.main.GetLastPlayableMap() - 3);
    }

    public void RefreshReplayedLevel()
    {

    }

    private void RefreshShownGoldAmount()
    {
        string gold = ProfileDataBase.main.GetCurrentGold().ToString();

        goldText_Shop.text = gold;
        goldText_Profile.text = gold;
    }

    private void RefreshShownStars()
    {
        string stars = ProfileDataBase.main.GetCurrentStars().ToString();

        starText_Profile.text = stars;
    }

    private void RefreshShownName()
    {
        string name = ProfileDataBase.main.GetName();
        nameText_Profile.text = name;
    }

    private void RefreshShownExperience()
    {
        string xp = ProfileDataBase.main.GetCurrentExperience().ToString();
        string lvl = ProfileDataBase.main.GetCurrentLevel().ToString();

        xpText_Profile.text = xp;
        lvlText_Profile.text = lvl;
    }

    private void RefreshShownStats()
    {
        string stats = ProfileDataBase.main.GetStatisticString();

        statList_Profile.text = stats;
    }

    private void RefreshAllShownValues()
    {
        RefreshShownGoldAmount();
        RefreshShownStars();
        RefreshShownName();
        RefreshShownExperience();
        RefreshShownStats();
    }
    #endregion


    private void SetDefaultStateColorsAndCheckMark()
    {
        // TODO: Obviusly, these are not the refined final colors. (states of shop elements)
        selectedColor = Color.yellow;
        lockedColor = Color.white;
        unlockedColor = Color.gray;


        lvlFilledStarColor = new Color32(255, 221, 85, 255);
        lvlEmptyStarColor = Color.white;

        checkMark.GetComponent<Image>().color = selectedColor;
        checkMark.SetActive(true);
    }

    public int GetCurrentLvl()
    {
        return currentLvl;
    }

    public bool IsPreMadeMap()
    {
        return IsPreMadeMap(out object o);
    }

    public bool IsPreMadeMap(out object id)
    {
        if (levelLayout.IsCreatedLevel(currentLvl, out id)){
            return true;
        }
        else
        {
            return false;
        }
    }

    #region ScreenManipulation
    public void SetShopActive(bool value)
    {
        if (value)
        {
            SetPanelActive(shopPanel);
        }
        else
        {
            SetPanelActive(menuPanel);
        }
    }

    public void SetProfileActive(bool value)
    {
        if (value)
        {
            SetPanelActive(profilePanel);
        }
        else
        {
            SetPanelActive(menuPanel);
        }
    }

    public void SetSettingsActive(bool value)
    {
        if (value)
        {
            SetPanelActive(settingsPanel);
        }
        else
        {
            SetPanelActive(menuPanel);
        }
    }

    private void SetPanelActive(GameObject panel)
    {
        foreach(GameObject p in panels)
        {
            p.SetActive(false);
        }

        panel.SetActive(true);

        RefreshAllShownValues();
    }

    public void SetHomeScreen()
    {
        SceneManager.LoadScene(0);
        canvas.SetActive(true);
    }

    public void SetGameScreen()
    {
        SceneManager.LoadScene(1);
        canvas.SetActive(false);
        Time.timeScale = 1;
    }

    public void SetMapEditorScreen()
    {
        SceneManager.LoadScene(2);
        canvas.SetActive(false);
    }

    public void SetDefaultState()
    {
        canvas.SetActive(true);

        SetShopActive(false);

        SetDefaultStateColorsAndCheckMark();


        GenerateLvlPrefabs(ProfileDataBase.main.GetLastPlayableMap() + 50);
        GenerateShopPrefabs(ProfileDataBase.main.NumberOfBallResources());
        ApplyTextureToShopPrefabs();

        ShowAllPlayableLevels(0);

        RefreshAllShownBallStates();
    }
    #endregion
}
