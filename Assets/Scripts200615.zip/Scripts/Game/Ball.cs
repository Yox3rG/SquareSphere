﻿using System.Collections;
using System.Collections.Generic;
using System.Dynamic;
using UnityEngine;

public class Ball : MonoBehaviour
{
    public int dmg { get; private set; } = 1;

    private static float destroyTime = .5f;
    private static float minSpeed = 10f;
    private static float minXValue = .1f;
    private static float minYValue = .1f;

    public bool IsShielded { get; set; } = false;

    private Rigidbody2D rb;
    [SerializeField]
    private Vector3 lastVelocity;
    //private int numOfCollisions = 0;
    //private Vector3 lastCollision;

    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        rb.velocity = Vector2.zero;
        //lastCollision = Vector2.zero;
        //numOfCollisions = 0;
    }

    void Update()
    {
        /*
        if (!IsUnderThreshold(rb.velocity))
        {
            lastVelocity = rb.velocity;
        }
        */
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        if (IsUnderThreshold(rb.velocity))
        {
            rb.velocity = -lastVelocity;
        }
    }

    /*
    void OnCollisionEnter2D(Collision2D collision)
    {
        if (numOfCollisions == 0)
        {
            ReflectVelocity(collision);
            lastCollision = collision.transform.position;
        }
        else if (lastCollision.x != collision.transform.position.x && lastCollision.y != collision.transform.position.y)
        {
            ReflectVelocity(collision);
        }
        numOfCollisions++;
    }

    void OnCollisionStay2D(Collision2D collision)
    {
        if (rb.velocity.magnitude < minSpeed)
        {
            rb.velocity = -lastVelocity;
        }
    }

    void OnCollisionExit2D(Collision2D collision)
    {
        numOfCollisions = 0;
    }

    private void ReflectVelocity(Collision2D collision)
    {
        Vector3 normal = collision.GetContact(0).normal;
        float speed = lastVelocity.magnitude;
        Vector2 direction = Vector2.Reflect(lastVelocity.normalized, normal);

        //Debug.DrawRay(collision.GetContact(0).point, normal, Color.blue, 5f);
        //Debug.DrawRay(collision.GetContact(0).point, direction, Color.green, 5f);
        //Debug.Log(speed + ", dir: \n" + direction + ", lv: \n" + lastVelocity);
        lastVelocity = rb.velocity = direction * Mathf.Max(speed, minSpeed);
    }
    */
    public void Return()
    {
        GetComponent<CircleCollider2D>().enabled = false;
        rb.velocity = (BallController.main.GetNewLocation() - transform.position) * (1 / destroyTime);
        Destroy(gameObject, destroyTime);
    }

    private bool IsUnderThreshold(Vector3 velocity)
    {
        if (velocity.x < minXValue && velocity.x > -minXValue)
        {
            return true;
        }
        else if (velocity.y < minYValue && velocity.y > -minYValue)
        {
            return true;
        }
        return false;
    }

    public void SetVelocity(Vector3 normalized)
    {
        lastVelocity = rb.velocity = normalized * minSpeed;
    }
}
