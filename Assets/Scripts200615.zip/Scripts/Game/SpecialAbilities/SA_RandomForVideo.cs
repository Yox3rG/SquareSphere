﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SA_RandomForVideo : SpecialAbility
{
    public override bool Activate()
    {
        throw new System.NotImplementedException();
    }

    public override Currency GetCost()
    {
        throw new System.NotImplementedException();
    }
}