﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SquareDataBase : MonoBehaviour
{
    public static SquareDataBase main { get; private set; } = null;

    public LastRowWarning warning;

    // Gameplay Properties.
    private int maxSpawnRoundCount = 5;
    private int currentRound = 0;

    // Generator Properties.
    private bool generateFromData = false;

    private int destroyablesGenerated = 0;

    public const int rows = 14, cols = 10;
    private int emptyRows = 5;

    private int mapSeed = 0;

    private float squareSize;
    private Vector3 startPosition;
    private Element[,] elements;

    private Stack<Element[]> elementsPushedOutOfScreen = new Stack<Element[]>();

    private Score score;
    private readonly float[] scorePercentages = { 0.3f, 0.5f, 0.8f };

    void Awake()
    {
        if(main == null)
        {
            main = this;
        }

        // Hardcoded version in use atm.
        //startPosition = new Vector3(-Camera.main.orthographicSize * Camera.main.aspect + squareSize / 2 + sideSize, Camera.main.orthographicSize - squareSize / 2 - sideSize, 0);

        elements = new Element[rows, cols];
    }
    
    void Start()
    {
        squareSize = ElementHandler.main.squareSize;
        float sideSize = ElementHandler.main.sideSize;
        startPosition = new Vector3(-Camera.main.orthographicSize * Camera.main.aspect + squareSize / 2 + sideSize, 3.44f, 0);


        if (MapDataBase.main)
        {
            // If we launched the testing from the Map Creator.
            if (MapDataBase.main.IsTesting)
            {
                GenerateSquaresFromData();
            }
            // Regular method of identifying the map.
            else
            {
                Stage resultLevel;
                if (Menu.main != null)
                {
                    generateFromData = Menu.main.IsPreMadeMap(out resultLevel);
                }
                else
                {
                    generateFromData = false;
                    resultLevel = new Stage(0);
                }

                if (!generateFromData)
                {
                    mapSeed = resultLevel.levelRandomNumber;

                    MapDataBase.main.GenerateRandomMap(mapSeed);
                }
                else
                {
                    MapDataBase.main.SetFileName(resultLevel.levelName);
                    if (!MapDataBase.main.LoadMap())
                    {
                        MapDataBase.main.LoadDefaultMap();
                    }

                }

                GenerateSquaresFromData();
            } 
        }

        score = new Score(CalculateScoreRequirementsForStars());
        GamePlayMenu.main.SetMedalValues(score.requirements);
    }

    #region PowerUpRelated
    // Actual powerups.
    public void DamageRow(int row)
    {
        int i = row;

        for (int j = 0; j < cols; j++)
        {
            if (elements[i, j] != null && elements[i, j].IsDestroyable())
            {
                SquareFrom(elements[i, j]).TakeDmg(1);
            }
        }
    }

    public void DamageColumn(int col)
    {
        int j = col;

        for (int i = 0; i < rows; i++)
        {
            if (elements[i, j] != null && elements[i, j].IsDestroyable())
            {
                SquareFrom(elements[i, j]).TakeDmg(1);
            }
        }
    }

    // Powerup behaviour.
    // HACK: not optimal destroying of powerups
    private void DestroyUsedPowerUps()
    {
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                if(elements[i, j] is PowerUp p)
                {
                    if(p != null && p.isDestroyedNextTurn)
                    {
                        Destroy(p.gameObject);
                    }
                }
            }
        }
    }
    #endregion

    #region SpecialAbilities
    public void SpecialAbilityMoveUp(int disctance)
    {
        for (int i = 0; i < 2; i++)
        {
            LiftRowsUp();
        }
    }

    public void SpecialAbilityBreakSides(int count)
    {
        score.IsDeathIncreasingNext = false;
        BreakSideCols(count);
        BreakSideRows(count);
        score.IsDeathIncreasingNext = true;
    }

    private void BreakSideRows(int count)
    {
        for (int i = 0; i < count; i++)
        {
            BreakRow(i);
        }
        for (int i = rows - count - 1; i < rows - 1; i++)
        {
            BreakRow(i);
        }
    }

    private void BreakSideCols(int count)
    {
        for (int i = 0; i < count; i++)
        {
            BreakCol(i);
        }
        for (int i = cols - count; i < cols; i++)
        {
            BreakCol(i);
        }
    }

    private void BreakCol(int index)
    {
        for (int i = 0; i < rows; i++)
        {
            BreakIfPossible(elements[i, index]);
        }
    }

    private void BreakRow(int index)
    {
        for (int i = 0; i < cols; i++)
        {
            BreakIfPossible(elements[index, i]);
        }
    }
    #endregion

    #region GeneratingTheMap
    private void GenerateSquaresFromData()
    {
        maxSpawnRoundCount = MapDataBase.main.GetMapLength() - rows + emptyRows;

        for (int i = rows - emptyRows - 1; (i >= 0) && (i >= -maxSpawnRoundCount); i--)
        {
            GenerateRowFromData(i, MapDataBase.main.GetNextLine());
        }
    }

    private void GenerateRowFromData(int row, List<SaveElement> saveElements)
    {
        foreach (SaveElement s in saveElements)
        {
            Vector3 pos = startPosition + new Vector3(s.col, -row) * squareSize;

            elements[row, s.col] = ElementHandler.main.DeserializeAt(s, pos);

            elements[row, s.col].SetRowAndCol(row, s.col);
            if(elements[row, s.col].IsDestroyable())
            {
                destroyablesGenerated++;
            }
        }
    }
    private void GenerateRowFromData(int row, Element[] rowElements)
    {
        foreach (Element e in rowElements)
        {
            if (e != null)
            {
                e.gameObject.SetActive(true);
                                        // That -row is kinda strange, careful.
                Vector3 pos = startPosition + new Vector3(e.col, -row) * squareSize;
                e.transform.position = pos;

                elements[row, e.col] = e;

                elements[row, e.col].SetRowAndCol(row, e.col);
            }
        }
    }
    #endregion

    #region ScoreRelated
    private int[] CalculateScoreRequirementsForStars()
    {
        int[] reqs = new int[Score.GetMedalCount()];

        int maxRoundCount = 20;
        int destroyableCount = 60;

        if (MapDataBase.main != null)
        {
            maxRoundCount = MapDataBase.main.GetMapLength() + emptyRows - 1;
            destroyableCount = MapDataBase.main.GetNumberOfDestroyables();
        }
        else
        {
            Debug.Log("MapDataBase not present at score calculation");
        }

        float minBlockPerRound = (float)destroyableCount / maxRoundCount;

        
        Debug.Log("Max rounds: " + maxRoundCount);
        Debug.Log("Destroyable count: " + destroyableCount);
        Debug.Log("Block/Round: " + minBlockPerRound);
        

        int bronzeValue = Mathf.FloorToInt((((minBlockPerRound + 1) * minBlockPerRound) / 2) * maxRoundCount) * 10;

        int medalIndex = (int)Score.MedalType.BRONZE;
        reqs[medalIndex] = bronzeValue;

        reqs[++medalIndex] =
            Mathf.FloorToInt((bronzeValue / scorePercentages[(int)Score.MedalType.BRONZE] * scorePercentages[medalIndex]) / 10) * 10;
        reqs[++medalIndex] =
            Mathf.FloorToInt((bronzeValue / scorePercentages[(int)Score.MedalType.BRONZE] * scorePercentages[medalIndex]) / 10) * 10;

        return reqs;
    }

    public void AddScore()
    {
        score.AddNext();

        GamePlayMenu.main.UpdateTargetScore(score.currentValue);
    }

    public int GetCurrentNumberOfStars()
    {
        return score.currentNumberOfStars;
    }
    #endregion

    #region CoreGamePlay
    public int GetCurrentRound()
    {
        return currentRound;
    }

    public int GetVisibleDestroyableCount()
    {
        return destroyablesGenerated;
    }

    public void NextRound()
    {
        if (CheckIfWon())
        {
            HideWarning();
            Victory();
        }
        else
        {
            score.ResetNextToDefault();
            DestroyUsedPowerUps();
            LiftRowsDown();
            if (maxSpawnRoundCount > currentRound)
            {
                if(elementsPushedOutOfScreen.Count != 0)
                {
                    GenerateRowFromData(0, elementsPushedOutOfScreen.Pop());
                }
                else if (MapDataBase.main != null)
                {
                    GenerateRowFromData(0, MapDataBase.main.GetNextLine());
                }
            }
            currentRound++;
        }
    }

    // Checks if DEFEAT
    // Checks if the WARNING has to be displayed
    private void LiftRowsDown()
    {
        // rows - 1 = last index
        int lastSafeRow = rows - 2;
        int overLastSafeRow = lastSafeRow - 1;

        if(IsDestroyableInRow(overLastSafeRow))
        {
            ShowWarning();
        }
        else
        {
            HideWarning();
        }

        // HACK: small performance issue, turning on and off warning when defeat.
        if (IsDestroyableInRow(lastSafeRow))
        {
            Defeat();
            HideWarning();
        }

        for (int i = lastSafeRow; i >= 0; i--)
        {
            for (int j = 0; j < cols; j++)
            {
                if (elements[i, j] != null)
                {
                    elements[i, j].transform.position += Vector3.down * squareSize;
                    if (elements[i, j].IsDestroyable())
                    {
                        SquareFrom(elements[i, j]).ResetTextPosition();
                    }

                    elements[i + 1, j] = elements[i, j];
                    elements[i, j] = null;

                    elements[i + 1, j].SetRowAndCol(i + 1, j);
                }
            }
        }
    }

    private void LiftRowsUp()
    {
        maxSpawnRoundCount++;
        Element[] upmostElements = new Element[cols];
        for (int j = 0; j < cols; j++)
        {
            if (elements[0, j] != null)
            {
                upmostElements[j] = elements[0, j];
                upmostElements[j].gameObject.SetActive(false);

                elements[0, j] = null;
            }
        }
        elementsPushedOutOfScreen.Push(upmostElements);

        for (int i = 1; i < rows - 1; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                if (elements[i, j] != null)
                {
                    elements[i, j].transform.position += Vector3.up * squareSize;
                    if (elements[i, j].IsDestroyable())
                    {
                        SquareFrom(elements[i, j]).ResetTextPosition();
                    }

                    elements[i - 1, j] = elements[i, j];
                    elements[i, j] = null;

                    elements[i - 1, j].SetRowAndCol(i - 1, j);
                }
            }
        }
    }

    private bool IsElementInRow(int index)
    {
        for (int j = 0; j < cols; j++)
        {
            if (elements[index, j] != null)
            {
                return true;
            }
        }
        return false;
    }

    private bool IsDestroyableInRow(int index)
    {
        for (int j = 0; j < cols; j++)
        {
            //if (elements[index, j] != null && elements[index, j].IsDestroyable())
            if (IsDestroyableAndNotNull(elements[index, j]))
            {
                return true;
            }
        }
        return false;
    }

    private bool IsDestroyableInCol(int index)
    {
        for (int j = 0; j < rows; j++)
        {
            //if (elements[index, j] != null && elements[index, j].IsDestroyable())
            if (IsDestroyableAndNotNull(elements[j, index]))
            {
                return true;
            }
        }
        return false;
    }

    private int SquaresLeft()
    {
        int count = 0;
        foreach(Element e in elements)
        {
            if (IsDestroyableAndNotNull(e))
            {
                count++;
            }
        }

        return count;
    }

    private bool IsDestroyableAndNotNull(Element element)
    {
        if(element != null && element.IsDestroyable())
        {
            return true;
        }
        return false;
    }

    private Square SquareFrom(Element element)
    {
        return (Square)element;
    }

    private bool BreakIfPossible(Element element)
    {
        if (IsDestroyableAndNotNull(element))
        {
            ((Square)element).Break();
            return true;
        }
        return false;
    }

    public void ShowWarning()
    {
        warning.Show(true);
    }

    public void HideWarning()
    {
        warning.Show(false);
    }
    #endregion

    private bool CheckIfWon()
    {
        return SquaresLeft() == 0 && maxSpawnRoundCount <= currentRound;
    }

    private void Victory()
    {
        Debug.Log("You won!");

        if (MapDataBase.main.IsTesting)
        {
            ReturnToMapEditor();
        }
        else
        {
            if(Menu.main.GetCurrentLvl() == ProfileDataBase.main.GetLastPlayableMap())
            {                                                      // #unintendedboobs
                ProfileDataBase.main.CompleteLevel(Menu.main.GetCurrentLvl(), score.currentNumberOfStars);
                Menu.main.RefreshLastShownLevelButtons();
            }
            else
            {
                ProfileDataBase.main.CompleteLevel(Menu.main.GetCurrentLvl(), score.currentNumberOfStars);
                Menu.main.UpdateStarAmountOnCurrentLevelButton();
            }
            if (ProfileDataBase.main)
            {
                if(ProfileDataBase.main.GetHighestScore() < score.currentValue)
                {
                    ProfileDataBase.main.StatSetHighestScore(score.currentValue);
                }
                ProfileDataBase.main.SaveData();
            }

            GamePlayMenu.main.GameOverPanel(true, true);
        }
    }

    private void Defeat()
    {
        Debug.Log("You lost.");

        if (MapDataBase.main.IsTesting)
        {
            ReturnToMapEditor();
        }
        else
        {
            ProfileDataBase.main?.StatIncreaseDeath();
            GamePlayMenu.main.GameOverPanel(true, false);
        }
    }

    private void ReturnToMapEditor()
    {
        Menu.main.SetMapEditorScreen();
    }
}
