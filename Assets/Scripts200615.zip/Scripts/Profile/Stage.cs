﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Stage
{
    public LayoutType type;

    public string levelName;

    public int levelRandomNumber;

    public Stage(LayoutType _type, string _levelName)
    {
        if(_type != LayoutType.GENERATED)
        {
            levelName = _levelName;
        }
        else
        {
            Debug.Log("Generated level type cannot have a name. Values given: \n" + _type + _levelName);
        }

        type = _type;
        levelRandomNumber = -1;
    }

    public Stage(int levelNumber)
    {
        type = LayoutType.GENERATED;
        levelRandomNumber = levelNumber;
        levelName = "";
    }

    public bool IsCreated()
    {
        if(type == LayoutType.GENERATED)
        {
            return false;
        }
        else
        {
            return true;
        }
    }

    public enum LayoutType
    {
        GENERATED,
        DEFAULT,
        COLORED,
        BOSS
    }
}
