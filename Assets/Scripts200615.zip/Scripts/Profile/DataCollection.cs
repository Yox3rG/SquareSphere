﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;

[System.Serializable]
public class DataCollection
{
    public Profile profile;
    public Statistics stats;
    public Shop shop;
    public Settings settings;

    private string fileLocation = "data";
    private string fileNameData = "data";
    private readonly string fileExtension = ".json";


    public DataCollection()
    {
        profile = new Profile();
        stats = new Statistics();
        shop = new Shop();
        settings = new Settings();
    }

    #region FileNameHandle
    public bool SaveData()
    {
        return SaveLoadHandlerJSON<DataCollection>.Save(this, GetDataFile());
    }

    public bool LoadData()
    {
        
        DataCollection temp = new DataCollection();
        bool dataOK = SaveLoadHandlerJSON<DataCollection>.Load(GetDataFile(), out temp);

        if (dataOK)
        {
            profile = temp.profile;
            stats = temp.stats;
            shop = temp.shop;
            settings = temp.settings;

            return true;
        }

        return false;
    }

    private string GetDataFile()
    {
        return GetCurrentFile(fileNameData);
    }

    private string GetCurrentFile(string filename)
    {
        return Path.Combine(fileLocation, filename + fileExtension);
    }


    public string GetFileLocation()
    {
        return fileLocation;
    }
    #endregion


    // Old code section.

    /*
    
    private string fileNameProfile = "profile";
    private string fileNameStats = "stats";
    private string fileNameShop = "shop";


    public bool LoadData()
    {
        bool profileOK = SaveLoadHandlerJSON<Profile>.Load(GetProfileFile(), out profile);
        bool statsOK = SaveLoadHandlerJSON<Statistics>.Load(GetStatsFile(), out stats);
        bool shopOK = SaveLoadHandlerJSON<Shop>.Load(GetShopFile(), out shop);

        return profileOK && statsOK && shopOK;
    }

    public bool SaveData()
    {
        bool profileOK = SaveLoadHandlerJSON<Profile>.Save(profile, GetProfileFile());
        bool statsOK = SaveLoadHandlerJSON<Statistics>.Save(stats, GetStatsFile());
        bool shopOK = SaveLoadHandlerJSON<Shop>.Save(shop, GetShopFile());

        return profileOK && statsOK && shopOK;
    }

    private string GetProfileFile()
    {
        return GetCurrentFile(fileNameProfile);
    }

    private string GetStatsFile()
    {
        return GetCurrentFile(fileNameStats);
    }

    private string GetShopFile()
    {
        return GetCurrentFile(fileNameShop);
    }
    */
}
