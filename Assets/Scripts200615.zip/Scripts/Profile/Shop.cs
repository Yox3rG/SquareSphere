﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Shop
{
    public List<bool> ballsUnlocked;

    // Split at every 5th. Not Serialized...
    private static List<Currency> _ballCostList;
    private static List<Currency> ballCostList { get
        {
            if(_ballCostList == null)
            {
                _ballCostList = new List<Currency>() {
                    new Currency(Currency.Type.GOLD, 10),
                    new Currency(Currency.Type.GOLD, 10),
                    new Currency(Currency.Type.DIAMOND_APPLE, 10),

                    new Currency(Currency.Type.GOLD, 10),
                    new Currency(Currency.Type.GOLD, 10),
                    new Currency(Currency.Type.DIAMOND_APPLE, 10),
                
                    new Currency(Currency.Type.GOLD, 10),
                    new Currency(Currency.Type.GOLD, 10),
                    new Currency(Currency.Type.GOLD, 10),

                    new Currency(Currency.Type.GOLD, 10),
                    new Currency(Currency.Type.GOLD, 10),
                    new Currency(Currency.Type.DIAMOND_APPLE, 10),
                    
                    new Currency(Currency.Type.GOLD, 10),
                    new Currency(Currency.Type.GOLD, 10),
                    new Currency(Currency.Type.GOLD, 10),

                    new Currency(Currency.Type.GOLD, 100),
                    new Currency(Currency.Type.GOLD, 100),
                    new Currency(Currency.Type.DIAMOND_APPLE, 100),
                    
                    new Currency(Currency.Type.GOLD, 100),
                    new Currency(Currency.Type.GOLD, 100),
                    new Currency(Currency.Type.GOLD, 100),
                    
                    new Currency(Currency.Type.GOLD, 100),
                    new Currency(Currency.Type.GOLD, 100),
                    new Currency(Currency.Type.DIAMOND_APPLE, 100),
                    
                    new Currency(Currency.Type.GOLD, 100),
                    new Currency(Currency.Type.GOLD, 100),
                    new Currency(Currency.Type.GOLD, 100),
                    
                    new Currency(Currency.Type.GOLD, 100),
                    new Currency(Currency.Type.GOLD, 100),
                    new Currency(Currency.Type.GOLD, 100),

                    new Currency(Currency.Type.GOLD, 200),
                    new Currency(Currency.Type.DIAMOND_APPLE, 200) };
            }
            return _ballCostList;
        }
        set
        {
            
        }
    }
    

    public int selectedBall;

    public Shop()
    {
        ballsUnlocked = new List<bool>();
        selectedBall = 0;
    }

    public int BallCostListCount()
    {
        return ballCostList.Count;
    }

    public Currency GetBallCost(int index)
    {
        return ballCostList[index];
    }

    public int UnlockedBallCount()
    {
        int count = 0;
        foreach(bool b in ballsUnlocked)
        {
            if (b)
            {
                count++;
            }
        }

        return count;
    }
}
