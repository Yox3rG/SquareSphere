﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class Currency
{
    private static List<Sprite> currencyIcons;

    static Currency()
    {
        currencyIcons = new List<Sprite>();

        Sprite temp = Resources.Load<Sprite>("gold");
        currencyIcons.Add(temp);
        temp = Resources.Load<Sprite>("diamond");
        currencyIcons.Add(temp);

        // Advertise currency has no sprite yet. Add it here.
        temp = Resources.Load<Sprite>("diamond");
        currencyIcons.Add(temp);
    }

    public enum Type
    {
        GOLD,
        DIAMOND_APPLE,
        AD_VIDEO
    }

    [SerializeField] private Type _type;
    [SerializeField] private int _amount;

    public Type type { get { return _type; } }
    public int amount { get { return _amount; } }

    public Currency()
    {
        _type = Type.GOLD;
        _amount = 0;
    }

    public Currency(Type type, int amount)
    {
        this._type = type;
        this._amount = amount;
    }

    public static Sprite GetCurrencyIcon(Type type)
    {
        return currencyIcons[(int)type];
    }
}
