﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;


public class StageLayout
{
    private static StageLayout main;

    private static Dictionary<int, Stage> levels;

    private int lastCreatedKey = 0;
    private int levelCount = 0;

    private int lastGeneratedValue = 0;

    // MapDataBase doesn't know about stage numbers, only the seed.
    private int lastNoTriangleSeed = 0;
    private int lastNoPowerUpSeed = 0;

    public static StageLayout GetMain()
    {
        if(main == null)
        {
            main = new StageLayout();
        }
        return main;
    }

    private StageLayout()
    {
        levels = new Dictionary<int, Stage>() {
            { 0, new Stage(Stage.LayoutType.DEFAULT, "tutorial01") },
            { 1, new Stage(Stage.LayoutType.DEFAULT, "tutorial02") },
            { 2, new Stage(Stage.LayoutType.DEFAULT, "tutorial03") },
            { 4, new Stage(Stage.LayoutType.COLORED, "colored01") },
            { 6, new Stage(Stage.LayoutType.BOSS, "boss01") }
        };

        lastCreatedKey = levels.Keys.Max();
        levelCount = levels.Count();

        // Change these when tutorial length changes.
        lastNoTriangleSeed = 3;
        lastNoPowerUpSeed = 6;
        
        int next = 0;
        for (int i = 0; i < lastCreatedKey; i++)
        {
            if (!levels.ContainsKey(i))
            {
                levels.Add(i, new Stage(next++));
            }
        }

        lastGeneratedValue = next == 0 ? next : --next;
        
    }

    public bool HasTriangles(int seed)
    {
        return seed > lastNoTriangleSeed;
    }
    public bool HasPowerUps(int seed)
    {
        return seed > lastNoPowerUpSeed;
    }

    public bool IsCreatedLevel(int levelNumber)
    {
        return IsCreatedLevel(levelNumber, out Stage l);
    }

    public bool IsCreatedLevel(int levelNumber, out Stage level)
    {
        // Chosen level is greater than any created level.
        if(levelNumber > lastCreatedKey)
        {
            int resultInt = levelNumber - lastCreatedKey + lastGeneratedValue;
            level = new Stage(resultInt);
            return false;
        }

        // Chosen level is part of the dictionary with the created maps.
        if (levels.ContainsKey(levelNumber))
        {
            levels.TryGetValue(levelNumber, out level);
            return level.IsCreated();
        }

        level = new Stage(-1);
        return false;
    }
}
