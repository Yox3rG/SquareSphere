﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class SaveElementLine
{
    public List<SaveElement> list = new List<SaveElement>();
}
