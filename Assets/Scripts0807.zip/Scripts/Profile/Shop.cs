﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Shop
{
    public List<bool> ballsUnlocked = new List<bool>();
    private List<int> ballCostList = new List<int>();

    public int selectedBall = 0;

    public int BallCostListCount()
    {
        return ballCostList.Count;
    }

    public int GetBallCost(int index)
    {
        return ballCostList[index];
    }

    public void SetCosts(List<int> costs)
    {
        ballCostList = costs;
    }
}
