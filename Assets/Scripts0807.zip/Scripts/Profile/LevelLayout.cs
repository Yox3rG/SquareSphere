﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;


public class LevelLayout
{
    private Dictionary<int, string> createdLevels;
    private Dictionary<int, int> generatedLevels;

    private int lastCreatedKey = 0;
    private int levelCount = 0;

    private int lastGeneratedValue = 0;

    public enum LayoutType
    {
        DEFAULT
    }

    // The enum is added for expandability for later, no use as of now.
    public LevelLayout(LayoutType type)
    {
        if (type == LayoutType.DEFAULT)
        {
            createdLevels = new Dictionary<int, string>() {
                { 0, "tutorial01" },
                { 1, "tutorial02" },
                { 2, "tutorial03" },
                { 4, "powerup01" },
                { 6, "powerup02" }
            };

            lastCreatedKey = createdLevels.Keys.Max();
            levelCount = createdLevels.Count();


            generatedLevels = new Dictionary<int, int>();
            int next = 0;
            for (int i = 0; i < lastCreatedKey; i++)
            {
                if (!createdLevels.ContainsKey(i))
                {
                    generatedLevels.Add(i, next++);
                }
            }

            lastGeneratedValue = next == 0 ? next : --next;
        }
    }
    
    public bool IsCreatedLevel(int level)
    {
        return IsCreatedLevel(level, out object o);
    }

    public bool IsCreatedLevel(int level, out object id)
    {
        int resultInt = 0;
        string resultString = "";

        // If the chosen level is greater than any created level.
        if(level > lastCreatedKey)
        {
            resultInt = level - lastCreatedKey + lastGeneratedValue;
            id = resultInt;
            return false;
        }

        // If the current level is part of the dictionary with the created maps.
        if (createdLevels.ContainsKey(level))
        {
            createdLevels.TryGetValue(level, out resultString);
            id = resultString;
            return true;
        }
        else
        {
            generatedLevels.TryGetValue(level, out resultInt);
            id = resultInt;
            return false;
        }
    }
}
