﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GamePlayMenu : MonoBehaviour
{
    public static GamePlayMenu main { get; private set; } = null;


    public GameObject gameplayPanel;
    public GameObject pausePanel;
    public GameObject gameEndPanel;

    public GameObject clearUI;
    public GameObject failUI;

    public Text lvlText;

    void Awake()
    {
        if(main == null)
        {
            main = this;
        }
    }

    public void Pause(bool value)
    {
        pausePanel.SetActive(value);
        if (value)
        {
            Time.timeScale = 0;
        }
        else
        {
            Time.timeScale = 1;
        }
    }

    public void GameOverPanel(bool visible, bool victory)
    {
        gameEndPanel.SetActive(visible);
        clearUI.SetActive(victory);
        failUI.SetActive(!victory);

        // Testing purposes.
        string temp = Menu.main == null ? "0" : Menu.main.GetCurrentLvl().ToString();
        lvlText.text = "level " + temp;
    }

    public void LoadNextLevel()
    {
        if (Menu.main != null)
        {
            Menu.main.LevelOnClick(Menu.main.GetCurrentLvl() + 1);
        }
    }

    public void ResetLevel()
    {
        if(Menu.main != null)
        {
            Debug.Log(Menu.main.name);
            Menu.main.LevelOnClick(Menu.main.GetCurrentLvl());
        }
    }

    public void SetHomeScreen()
    {
        if (Menu.main != null)
        {
            Menu.main.SetHomeScreen();
        }
        else
        {
            UnityEngine.SceneManagement.SceneManager.LoadScene(0);
        }
    }
}
